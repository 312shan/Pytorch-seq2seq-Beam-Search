Moses Snapshot
-----

This is the bare minimum preprocessing scripts checked out from Moses GitHub
repository at the following commit (12 December 2017):

```
commit 3a0631a05b7f53a7f387ca8ddca432f5ddb22029
Author: Hieu Hoang <hieuhoang@gmail.com>
Date:   Tue Dec 12 15:30:56 2017 +0000

    better default
```
