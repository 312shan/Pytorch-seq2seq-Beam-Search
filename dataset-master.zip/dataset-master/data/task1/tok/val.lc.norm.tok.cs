skupina mužů nakládá bavlnu na náklaďák .
muž spí na gauči v zeleném pokoji .
chlapec má na sobě sluchátka a sedí ženě na ramenou .
dva muži rozdělávají modrý rybářský stan na zamrzlém jezeře .
plešatící muž má na sobě červenou záchrannou vestu a sedí na malé loďce .
dáma v červeném kabátě drží modravou kabelku pravděpodobně z asie a skáče do vzduchu kvůli snímku .
hnědý pes běží za černým psem .
malý chlapec v dresu giants odpaluje baseballovou pálkou příchozí míč .
muž telefonuje v přeplněné kanceláři .
usmívající se žena v broskvové topu drží horské kolo .
malé dítě stojí samo na rozeklané skále .
osoba na sněžném skútru uprostřed skoku .
tři malé děti stojí okolo bílomodrého sudu .
žena sedí u vystavených sušených květin na venkovním trhu .
žena hraje píseň na housle .
tři lidé jedou na dvou terénních motorkách a jedné čtyřkolce v suché trávě .
polonahý muž spí venku na židli .
skupina lidí na parkovišti stojí před chatrčí .
mladá žena vyrábí koberečky v deštném pralese .
tři holky se ksichtí a jedna pije , když stojí na rušné ulici .
muž v černém tričku stojí nad davem v rušném baru .
žena a muž jsou přes dřevěný provazový most , který má vedle sebe výstražnou ceduli .
muž v sukni skáče a do toho žongluje s noži .
asiatka v zeleném klobouku a zástěře servíruje nápoje na tácu .
dělníci stojí na nějakém stroji .
dva psi s oranžovou hračkou ve vysoké trávě .
roztomilé mimino se směje na další dítě .
tři muži jdou po silnici v horách .
člověk parasailuje na velkou vodní plochou .
bagr jede hlínou při stavbě opěrné zdi .
holčička běhá v parku .
člověk přechází silnici a vyhýbá se vylité barvě .
dítě si hraje na hřišti , visí z tyčí .
člověk má na sobě červené tričko s dlouhým rukávem , leží na zdi před lampou velmi neobvyklým způsobem .
skupina lidí se shromáždila okolo muže v obleku a malého kluka .
žena sedí v tmavém baru .
lidé jdou po chodníku a prochází venkovním trhem .
muž s modrým batohem si čte noviny , když čeká na metro .
velký hnědý pes strká čumák před rozstřikovač .
blonďatý chlapec v modrém tričku stojí a usmívá se před výrobkem ze zelené nylonové látky .
malý bělošský chlapec zametá podlahu terasy velkým koštětem .
osoba se chystá hodit zelenou bowlingovou kouli po dráze .
skupina hraje rock návštěvníkům baru .
postarší muž se prochází se psem na červeném vodítku .
muž řídí červené staromódní závodní auto .
mladí dospělí v červených , žlutých a černých tričkách v řadě předvádí své číslo .
mladý chlapec hází kámen do stojaté vody .
dvě ženy s krátkými vlasy jsou otočené k sobě a ta blonďatá něco říká .
postava v důmyslném kostýmu před výrazně zdobenou stavbou .
pes jde malým potom s hadrem v tlamě .
tři malí psi u něčeho čuchají .
dva muži pádlují na kajaku v řece se zelenými stromy na obou březích .
dvě holky jdou po ulici .
skupina dětí sedí vzadu v dodávce a spolu se dívají na knihu .
lidé na pláži si prohlížejí obraz srdce namalovaný na obloze .
dívka sedí pohodlně na veřejném místě , čte si a udržuje knihu otevřenou rukou , na které má prstýnek s motýlem .
muž má oběd v restauraci .
muž v obleku a brýlích má nějaký předmět v rukou .
muž v černém neoprenu surfuje na vlně .
žena s růžovou kabelkou sedí na lavičce .
tři ženy se usmívají a sedí .
červené letadlo přelétává nad lodí a zanechává při tom růžovou kouřovou stopu .
muž při sportovním lezení šplhá na skálu .
dva stavební dělníci pomáhají nakládat náklaďák na městském staveništi .
žena v barevném oblečení prochází kolem bílé dodávky s kanystry .
žena v modrém klobou a žluté sukni skáče u lilií .
muž ve zlatém oblečení stojí u svého starého kola .
mimino se dívá na listy na větvi stromu .
uklízeč se chystá vytírat stanici vlaku .
dva malí černí kluci si hrají s láhvemi s umělé hmoty a náramně se baví .
na semaforu svítí zelená a lidé se dívají na motorky .
dva lidé šplhají na skálu po provaze .
muž a žena rybaří na pláži .
dítě dělá salto , když skáče na trampolíně .
děti jedou na řetízkovém kolotoči
dva lidé drží vzhůru nohama obří glóbus s průměrem asi čtyři stopy a dítě vypadá , že skáče přes antarktidu .
dva muži z armády hrají baseball .
žena v černých šatech tlačí vozík s termoskami dlážděném chodníku .
policista zastavuje auto na kraji silnice .
muž stojí na molu vedle lodi na klidném jezeře .
skupina skotských důstojníků na přehlídce .
žena a dítě spolu sedí v rámu dveří u šedého a muž jde okolo .
osamocený hasič pomáhá zkrotit veliký oheň .
osoba ve fialovém tričku maluje na zeď obraz ženy .
malá dívka leží na podlaze a její mladší sestra dělá , že je zdravotní sestřička .
mladší a starší žena v tradičních šatech u kolovrátku , tři lidé v moderních šatech jsou od pasu dolů zobrazeni v pozadí .
žena jde hlubokým sněhem ze strmého kopce .
řidič fedexu poslouchá dělníka v zelené helmě , zatímco se nakládá vybavení .
hnědý pes má na sobě černý obojek .
hnědobílý pes běží dolů po žlutomodré rampě .
dítě se chystá číst knihu .
starší japonec se pokouší opravit malý červenošedý stroj .
malé dítě a žena stojí vedle kohouta v kleci .
dítě převlečené za spidermana zvoní na zvonek u dveří .
muž v hnědém drží světelný meč .
mladá žena stojí a zpívá do mikrofonu , zatímco muž za ní drží kytaru .
dvě děti hrabou díry v hlíně .
hodně těchto lehátek je prázdných a leží na nich jen hrstka lidí , kteří si užívají sluníčka .
nějací muži sedí na lodi u pláže s naskládanými kládami a klacky .
mladý muž nese něco ve velkém černém igelitovém pytli na odpadky .
starší muž s nadváhou obrací palačinku při přípravě snídaně .
muž ve žlutém obleku na pódiu s piánem a další muž hrají na basu .
několik lidí stojí u stromů za úsvitu .
hnědý pes kouše velký kus dřeva .
turista pózuje ve vyprahlé horské krajině .
skupina dětí si hraje ve vodě pod mostem .
žena se směje vedle muže , který se také směje a drží cukrovou vatu .
dvě ženy stojí před třídou dětí a mluví o knížce .
dvě brunetky hovoří ve třídě plné blonďatých dětí .
člověk , který má na sobě čepici a šálu , se dívá doprava .
dva lidé jdou přes ulici .
starý muž drží jednoho , zatímco další jeho pes mu šplhá do klína .
tři děti se dívají na muže , který hraje na pódiu na kytaru .
chlapec si bere kolík od dívky uprostřed závodu .
modrý jeep jede do hluboké , bahnité vody .
dáma s černým kloboukem fotí a padá sníh .
muž sedí na zemi a hraje na kytaru .
pes šlape do mělké vody ve skalnatých horách .
mladá asiatka skáče do vzduchu v části města , kde je hodně lidí .
tři muži hrají na pódiu .
čtyři lidé protestují proti tomu , jak equinox zachází s mladými dělníky .
muž dělá hamburgery na černém grilu .
muž v kšiltovce se opírá o slabou tyč .
malý chlapec ve žlutém tričku visí na kruhu a okolo jsou ostatní děti .
malé dítě jí ovoce a pije sklenici džusu .
jeden muž a dvě ženy v šortkách jdou po ulici .
dva pudli běží sněhem .
malá zrzavá holka má na sobě oblek spidermana a jede na hračce koně .
muž v bílé loďce na rybníku .
lyžaři před chatou .
lidé jsou fotografováni při horolezení nebo horské turistice .
několik lidí plave ve vodě .
ženy v plavkách hrají za slunného dne plážový volejbal .
muž a žena sedí naproti sobě u stolu v restauraci .
matka a dvě děti pózují a dělají vtipné obličeje .
zlatý retrívr plave ve vodě s červenou hračkou v hubě .
čtyři muži stojí u žlutého auta .
skupina mužů , žen a dětí v kloboucích se baví na pláži .
malý kluk v dupačkách leze po hnědé podlaze .
malá holčička dává dar armádě spásy vedle vstupu do obchodu , kde jsou plastové nádoby .
žlutý pes nese míč v tlamě na pláži .
muž v červeném triku a dvě děti stojí před starou budovou .
muž se dívá na ženu , když jsou na baru .
kapela hraje na venkovním pódiu u řeky .
dvě ženy se usmívají na společenské události .
žena má na sobě růžové tričku a muž v pruhovaném svetru ji ukazuje nějakou práci s jehlicí .
dítě sedící na skále .
muž sedí na židli s pivem v rukou a opéká si něco k jídlu na dřevěné tyči .
policista v uniformě má sluchátko .
muž v hasičském oblečení přechází ulici v blízkosti bílého autobusu a červeného nákladního auta .
černobílý pes plave v čisté vodě .
hudební skupina hraje na pódiu při koncertě .
tři lidé hrají na hudební nástroje a další člověk vypadá , že zpívá .
muž hraje na klávesy a zpívá do mikrofonu .
malý chlapec skáče do vody .
žena si čte pohlednici , sedí na konci gauče a další žena stojí vedle ní a drží sklenici s pitím .
dělníci na stavbě tvrdě pracují .
muž se holí a sedí na pláži u oceánu .
blonďatá žena v modrém triku rozbaluje čepici .
dva muži si povídají za varhany a osamocená žena stojí po jejich pravici .
mladý blonďatý muž mluví do mikrofonu .
hotelový zřízenec v plášti tlačí náklad zavazadel .
pres se krčí mezi rostlinami a dívá se do foťáku .
hudební skupina vystupuje na pódiu před davem lidí .
tři psi si hrají ve sněhu .
muž a žena stojí u stromu a hovoří spolu .
pes skáče za žlutočerným míčem .
starší žena v šedočerveném svetru vaří pokrm .
žena v kabátu je před domem a sněží .
žena nese další ženu na zádech , mají na sobě cvičební úbory .
dítě stojí vedle kočárku a drží meč .
chlápek s kudrnatými vlasy skateboarduje po rampě se žlutými písmeny .
muž kutálí kulatý stůl po podlaze .
skupina lidí ve člunu na moři .
muž ve žluté košili stojí na chodníku a něco měří .
žena v modré košili a džínách vyhazuje něco do popelnice .
žena v masce dominy drsnými vlasy je na večírku .
osoba parasailuje na hřebenu vlny .
muži v modrých uniformách sedí v autobuse .
auto atv se snaží dostat z díry .
muž sráží dalšího , když hrají fotbal .
fotbalový hráč v červeno-bílém hovoří s trenérem .
dvě dívky sedí u zdi a dívají se na zápas .
trenér ou má na hlavě sluneční brýle v průběhu fotbalového zápasu .
fotbalový tým má na sobě červená trička a červené helmy .
kluk v černém oblečení dělá hvězdu na pláži .
pózují na fotku .
muž v zeleném tričku dává pusu batoleti , když sleduje běžce na trati .
pět členů kapely hraje píseň .
tři ženy sedí na zemi dece s dítětem a baví se .
muž s chlapcem sedí u oltáře a drží zvonky .
muž ve slunečních brýlích pomáhá dítěti ve slunečních brýlích sjet dolů skluzavce .
pes běží trávou k fotografovi .
dívka s dlouhým copem je připravená hodit míč další hráčce na hřišti .
dva muži zápasí na žlutomodré podlaze .
dívka v červenomodrém dresu a modrých šortkách je připravena k hodu míčem .
sedící muž pracuje rukama .
hnědý pes běží po pláži a nese klacek .
osoba vesluje na vodě .
muž v červenobílé pruhované košili sedí na stoličce u stánku s párky v rohlíku .
muž fotí bílé a žluté tulipány .
dva muži ve fezech diskutují na venkovním trhu .
muž a hoch si hrají se psem při západu slunce na pláži .
horkovzdušný balón přistává , muž ve stínu je v pozadí .
ten muž má na sobě čepici nebo klobouk .
ženě malují na obličej černé čáry a třpytky .
batole v džínové čepici si hraje na pneumatice .
dav lidí stojí na ulici před řadou bílých stanů .
dav lidí prochází parkem .
žena s tmavými vlasy má na sobě modrou blůzu a sluneční brýle drží transparent a malá holčička se zapletenými vlasy píše na transparent .
množství asijských dětí dělá vláček pod vietnamskou cedulí .
kovboj jezdí v rodeu na koni , který vykopává nohama .
ženich a nevěsta při svém novomanželském polibku .
dva záchranáři podkládají vlak .
muž pracuje na železnici v železniční stanici .
pár dělníků , míchají beton v trakařích , staví nebo opravují zeď , zeď je ještě vlhká .
kapela hrající na chodníku .
muži v oranžových oblecích sledů stroj , jak hrabe vedle něčeho , co vypadá jako koleje metra .
mladí dospělí v neformálním oblečení jdou po trávě .
velký hnědý pes běží mělkou vodou .
muž a ženy jdou přes prázdnou ulici .
muž nabalený do chladného počasí stojí v koši a pracuje na elektrických drátech .
dvě děti ve žlutých kabátcích si hrají v blátě .
několik lidí jede na horské dráze hlavou dolů .
žena sedí s malým chlapcem na křesle .
skupina lidí stojí přibližně v řadě na dlážděné podlaze .
malá holka plave v bazénu .
kluk v oranžovém tričku se směje a kluk v modrém tričku se na něj dívá .
malé dívka stojí venku v louži .
malá blonďatá dívka drží sendvič .
čtyři lidé se snaží spravit kolo v parku
promáčený hnědý pes vylézá z vody .
pres běží přes trávu s míčem v tlamě .
skupina lidí čeká za zábranou a dívá se doprava .
dítě , které má na sobě červenou mikinu , visí hlavou dolů ze stromu .
obsluha hry na pouti si bere peníze od dvou soutěžících .
kluk se směje do foťáku ve skupině sedících dětí .
dvě děti bez triček sedí na kraji fontány .
muž si natahuje mikinu , když má kajak u nohou .
starý muž jde s deskami v ruce .
nezaujatá mladá žena a starší muž stojí u baru .
mladý blonďatý chlapec skáče z postele na postel .
malé dítě máchá červenou baseballovou pálkou .
muž mluví do mobilu před sportovním obchodem .
dvě maminky poslouchají malé dítě .
žena v modrém tričku hraje na hudební nástroj .
toto je rušná křižovat ve velkém městě v noci .
muž sedí v mělké vodě vedle velké kamenné tváře .
pár turistů si dává přestávku , aby se vyfotili .
čtyři lidé ve stylu goth jdou po ulici se stromy v pozadí
4 lidé jsou připoutaní před jízdou v zábavním parku
chlapec předvádí trik z kovové tyče na skateboardu .
muž na pláži staví hrad z písku .
velký hnědý pes honí malého hnědého psa .
muži v bílých úborech zdvihají ruce .
žena hází frisbee psovi a za ní běží baseballista v dresu .
černý pes stojí v trávě a má v hubě plastovou věc .
loď s lidmi a jejich věcmi je na vodě .
skupina závodních silničních cyklistů se naklání v zatáčce .
tři lidé sedí venku u stolu , o který jsou opřena umělecká díla .
bílá žena a černý muž jsou po ulici .
muž v bílém tričku maluje uprostřed silnice vydlážděné kameny .
hnědo-černo-bílý pes štěká nahoru na strom .
muž s modročerveně pomalovaným obličejem pózuje spolu se ženou .
dva chlapci hrají hru s kuličkami .
dva muži čekají na zadním sedadle v autě a řidič si sedá na sedadlo řidiče .
chlapec se houpe na houpačce .
černoch se dívá na druhého , který si hraje pod vodopádem .
osoba s červeným batohem na výletě .
asijský dodavatel ovoce a zeleniny a jeho výběr banánů , pomerančů , melounů a dalšího na jeho loďce .
velký dav stojí s velkými budovami v pozadí .
tři ženy s tmavými klobouky zahalené do tmavých šátků spolu mluví na dlážděné ulici a u nich sedí pes .
muž v bílém si dělá kebab .
osoba v neonově růžové paruce a žlutém tričku se dívá přes pláž .
muž se dívá na ženu , která kouří na chodníku .
muž v černém tričku , hnědých kapsáčích drží lopatu nad hlavou .
muž olizující tvář ženy s brýlemi .
dítě jde před dalším .
malý chlapec v pozadí dělá králičí uši dívce , která stojí před ním .
mimino v růžovém fleecovém oblečku leží v suchém listí a směje se .
detail ženy s krátkými červenými vlasy .
fotbalista v zeleném dresu běží z hřiště .
holka vede svého psa přes překážku .
několik dětí sedí ve třídě na barevném koberečku a hlásí se .
námořník stojí nahoře na nástupním můstku do velké lodi .
středně velký pes skáče , aby chytil malý látkový létající talíř .
muž v šedém tričku odpočívá .
černý pes skáče vodou , zatímco drží klacek v tlamě .
dva černí psi běží vedle zpevněné cesty , každý po jedné straně .
čtyři lidé v neformálním oblečení stojí venku a drží pytle na odpadky .
lidé a velbloudi odpočívají v poušti .
čtyři psi si hrají v kruhu a jeden černý pes jde pryč .
muž v armádní uniformě mluví do mikrofonu .
skupina asiatů na výstavě aut zírají a fotí si nové auto .
plavec plave v bazénu .
žena v bílém triku si uvnitř domu hoví na gauči .
muž vedle dvou mladých dívek dává pokyn rukou .
dívka v bílém triku ve tmavém pokoji fouká do bublifuku .
kluci a holky z nějakého východního národa se smějí na poli .
dítě v oranžovém tričku skáče z balíků slámy a ostatní děti se dívají .
kluk dělá triky na skateboardu .
muž se natahuje , aby pracoval s kabely nad stolem .
batole sedí u stolu a svačí .
čtyři děti s batůžku se otáčí čelem k foťáku , když jdou po vesnické ulici .
muž s dredy si zacpává ucho aby slyšel telefonát .
muž skládá velké měkké disky na hřídel v průmyslovém prostředí a další muž se dívá .
pes na trávě se dívá nahoru .
žena a malé dítě se baví při deskové hře .
4 děti sedí na římse a konverzují .
malý hnědý pes uprostřed rostlin v květináči a popadaného listí .
dva muži malují budovu na bílo a třetí jde okolo a telefonuje .
nějací lidé se v kanceláři dívají na obrazovku počítače .
dvě ženy si prohlížejí snímek ve fotoaparátu .
blondýna v hnědém kovbojském klobouku dělá vulgární gesto do foťáku .
bílohnědý pes běží po trávě .
dospívající dívka čte knihu ve třídě , poznámky má na stole a vypadá znuděně .
dvě malé dívky jdou listím .
nevěsta upravuje svému ženichovi květinu na jeho saku a drží při tom kytici .
žena dává oranžovou růži do knoflíkové dírky na klopě mužova saka .
dvě ženy s kočárky jdou po ulici zapadané listím .
čtyři ženy oblečené do směšných kostýmů .
tato stará asiatka odpočívá a ovívá se za zjevně velmi horkého dne .
dívky v bikinách hrají beach volejbal .
muž v brýlích a malá dívka v záchranné vestě plavou v bazénu .
tři děti v hnědých tričkách a džínách skáčou venku , kde je na zemi listí .
žena se soustředí na curling .
osoba nese množství tašek .
dítě poblíž modré plošiny , na které stojí barevné stvoření .
mladík s přihlouplým výrazem stojí mezi bavícími se lidmi .
dítě ve školní třídě po skončené výuce , možná .
muž na wakeboardu ve vodě .
dětí zírají z okna modré budovy s červenými okenicemi .
muž s prošedivělými vlasy , s vousy a brýlemi v černém sedí na trávě .
žena a její dvě děti jsou na pláži a žena skáče vysoko do vzduchu .
pár mužů jde po městské ulici .
chlápek dělá trik na kole v parku .
muž ve jasně barevné bundě na lyže s dalšími na evropské ulici .
žena ve žlutém triku a slunečními brýlemi jde po chodníku .
dvě ženy se dívají na spoustu domů pod sebou .
dva velcí psi dovádějí v trávě .
lidé oblečení navrstveném oblečení se společně pohybují .
skupina lidí jí v restauraci .
žena v černém tričku vypadá , že jede nahoru po eskalátoru .
místnost plná sedících a stojících dětí s osmi růžovými balonky zavěšenými u stropu .
muž a žena společně pózují na dlážděné ulici .
dva psi pobíhají a hrají si ve sněhu .
malý pes skáče na ulici .
muž v černém tričku hraje na sedmistrunnou baskytaru na pódiu .
chlapec a starý muž s vycházkovou holí si povídají .
dívka v bílém tričku , černých šortkách a čelence hraje volejbal .
dva muži stojí na ulici , která je pokrytá graffiti .
kluk v triku a šortkách drží sněhovou kouli a je otočen směrem k zasněžené hoře .
muž visí , když plachtí na moři .
dva husaři na koních oblečení v extravagantních kostýmech , každý držící šavli v pravé ruce a otěže v levé ruce .
pes běží hlubokým sněhem .
středně velká skupina lidí pózuje před foťákem .
velký hnědobíle flekatý pes leží na bundě na ulici .
dvě náctileté drží , která se ukazuje na tečku , a usmívající se .
matka a syn jedou na bobech a smějí se .
muž v černém tričku vaří podle kuchařky v neuklizené kuchyni .
žena v bílém hraje na černou kytaru .
snowboardista skáče ve vzduchu vedle lanovky .
několik lidí stojí v místnosti a jí .
muž v klobouku hraje na neobvyklý nástroj u výstupu z metra .
týpek sjíždí parapet u větrného mlýna
žena v bílém tričku a černých kalhotách tančí hula-hop a dívá se na ni velká skupina lidí .
starší muž dělá rozhovor s druhým v závodním dresu .
dva muži v červených úborech předvádějí bojová umění .
malé dítě jede blátem na motorce .
dítě v klobouku a bundě běhá venku na kamenném povrchu .
dítě sedí v davu na ramenech svého otce .
dva staří muži v kloboucích podřimují venku na sluníčku .
dva hoši ve stanu se usmívají na fotografa .
teple oblečená žena v černém klečí s malý světlehnědým psem před davem přihlížejících .
dva muži chystají nějaké elektronické vybavení .
žena , která nese tašku trader joe &apos; s grocery , usnula ve vlaku .
cyklista dělá trik ve vzduchu .
mladý muž v zelené mikině čte noviny na pláži .
muž v zelené bundě se usmívá .
muž šplhá na strmou skálu s jištěním .
mladý muž jede přes ulici na podomácku vyrobeném kole .
dva hnědí psi zápasí na travnatém kopci .
člověk v dlouhém červeném kabátě jde před budovou .
zahraniční žena sedí s hodně barevnou látkou .
dva muži za plotem skáčou do vzduchu a drží basketbalový míč .
muž s brýlemi u mikrofonu se dívá na papíry , které má v ruce .
dítě v zeleném tričku druží u pusy červený balónek .
muž s potetovanou paží něco smaží .
čtyřčlenná skupina hraje živé vystoupení .
skupina mladých asiatů běží maraton .
muž táhne předměty na vozíku .
tři velcí psi si užívají skotačení ve sněhu .
pták letí přes vodu .
skupina rodičů sedí na venkovním shromáždění .
žluté auto uhání po sněhovém poli .
skupina dětí si posedala a hraje hudební nástroje .
skupina dospělých sedí u stolu a poslouchá prezentaci .
žena oblečená v zeleném tričku čte prezentaci své třídě .
mladí lidé jsou zapálení do hry .
baseballisté v modrobílých dresech hrají baseball na hřišti .
žena a dva chlapci se dívají na informační stanici .
skupina lidí běží maraton pro dobročinnost .
dvě ženy stojí s hůlkami ve hlubokém sněhu .
lidé spolu stojí před sochou zvířete a všichni na sobě mají zimní oblečení .
mladý lyžař se dívá do foťáku .
dvě mladé dívky oblečené v růžovém pyžamu sedí na podlaze před velkými okny a hrají si s hracím domkem .
žena a dítě jedou na velbloudovi u oceánu .
muž s rukou na čele se směje v zaplněném baru .
ulice je plná lidí v kabátech .
dva muži v cizí zemi se smění , jeden stojí a druhý sedí se skříženýma nohama .
malý hnědý pes běží v trávě .
pouliční restaurace v noci .
snowboardista dělá trik .
asijská žena v doručovatelské uniformě strká do velké hromady balíků .
žena v modré košili jede na kole .
žena v bílem tenisovém dresu vyskakuje , aby trefila míček .
mladá žena uvnitř cvičí na strunný nástroj .
nevěsta a ženich se fotí a poblíž stojí dva muži .
žena držící černo-bílého psa .
chlapec v červeném tričku zkouší hrát na kytaru .
mladá úřednice kontroluje nové emaily od klientů .
tři straší ženy ve vánočně vyzdobeném obýváku a notebook vaio jsou ve středu pozornosti .
bílý chlupatý pes skáče a chytá hračku .
matador v barevném oblečení jede na býkovi .
děti se koupou ve vodě z obrovských sudů .
světlehnědý pes skáče se žlutým míčkem v tlamě .
skupina lidí v modrých tričkách na sportovní události .
tenista ve žlutomodrém dresu a modrou čelenkou .
dvě malá děvčata v modrých šatičkách se usmívají .
malá dívka v růžové baletní sukénce zkouší tancovat se šátky .
dva lidé běží na vrcholu hory .
skupina žen tancují balijské tance v barevných kostýmech a makeupu .
cyklista skáče v lese .
několik lidí jde podél bílého plotu v cizí zemi .
žena stojí na cihlové zdi a fotí .
žena v bílých šortkách , žlutém tílku a bílých sandálech vypadá , že hází klackem .
osoba jede na terénní motorce .
malá asijská dívka sedící v černém kbelíku jí marshmallow a má na tváři široký úsměv .
dva teriéři si hrají na dřevěné podlaze domu .
batole s dudlíkem v červeném tričku se zahradní hadicí .
náctiletý kluk na kole dělá triky .
starý muž má na sobě černou bundu a dívá se na stůl .
muž v modrém tričku jde vedle muže v červeném .
žena vysí ze stromu na pruhu látky omotaném kolem nohy .
malá bosá holčička s helmou jde po spadlém stromu pokrytém mechem .
černý pes skáče přes pestrobarevnou překážku .
chlapec v modrém , který hraje fotbal , se chystá kopnout do míče .
skupina cyklistů se chystá na závod .
chlápek utíká před černým býkem .
kluk s čírem honí husu v parku .
malý hnědobílý pes běží po chodníku .
dvě děti dávají obličeje do obrazu rytíře a princezny .
stíny dvou mužů na lanech .
černý pudl si hraji s další psem a suchém hřišti .
několik lidí si vychutnává cigarety u popelníku .
bílý pes s hnědým flekem skáče ze břehu do vody .
fotograf pořizuje snímek nápisu na dveřích .
malá holčička v kostičkovaných šatech a velkým modrým míčem vedle plotu z drátěnky .
muž trénuje box .
skupina mladých lidí pózuje ve vzduchu na písčité pláži .
žena drží housle .
cestovatelé jsou na túře za velmi chladného dne .
muž v šedém tričku dělá trik na skateboardu na schodech .
tři muži jdou vedle stanu , na kterém je bilboard .
malá holčička stojí na louce .
chlapec v zeleno-žlutém dresu se učí boxovat .
muž a žena hrají venku hru .
malá holčička má na sobě šaty , sandály a běží po trávě .
žena s fialovými vlasy a muž ve slavnostní uniformě .
lidé tancují a tleskají .
muž jde po ulici a zírá na kolemjdoucí pár .
muž v bílém tričku a pruhovaných kraťasech hraje na varhany a pozoruje ho muž ve žlutém tričku .
velká skupina lidí sleduje představení na pódiu .
auto jede po prašné trati a zanechává za sebou oblak prachu .
skupina lidí poslouchá muže , který mluví venku .
vousatý plešatý muž v proužkované košili spočívá hlavou na rameni jiného muže .
chlapec se chystá vykopnout míč na bránu .
cyklista na kole jede po silnici kolem kamenů pokrytých sněhem .
dlouhovlasý muž v oceánu pohazuje mokrými vlasy .
chlapec a muž oblečení jako rodeoví klauni stojí v písku .
malá holčička se směje a ukazuje palec vzhůru , když pózuje před želvou .
muž v modrém jede na motorce po dráze .
člověk se snaží na padáku při poklidném západu slunce .
servírka stojí za přepážkou s koláči .
dva cyklisté přejíždějí ulici v chladném kalifornském dni .
skupina muzikantů nahrává hudbu .
dva lidi hrají vodní volejbal v bazénu .
kavárna na rohu s oválným obrazem na rohu budovy .
chlapec zvedá druhého chlapce na zádech .
žena používá velký foťák a stojí na ulici .
žena má na sobě velký modročervený klobou .
žena si barví tvář a chlapec s čírem jí drží zrcadlo .
multikulturní skupina dospělých , muž s tetováním něco hází .
muž v modré košili jede na jednokolce a u toho drží hořící pochodně .
malé dítě si hraje s rozstřikovačem .
čtyři děti si hrají před vchodem a jejich otec je pozoruje .
muž drží nemluvně a opírá se při tom o budovu .
žena se dvěma medailemi kolem krku ukazuje sedm prstů .
dva muži zápasí při hře .
dvě holčičky jedí koláč , jedna z nich má modrou polevu na obličeji .
žena nandavá helmu malé holčičce .
dav sleduje někoho ve svém středu .
chlapec v parku si hraje se dvěma oranžovými míči .
malá blonďatá holčička stojí na polštáři a usmívá se se zavřenýma očima .
muž s kytarou zpívá do mikrofonu .
muž s korálky mardi gras okolo krku drží tyč s transparentem
muž v zeleném a žena v černém se protahují .
muž si fotí jiného muže a jeho dva psy na travnatém pahorku .
muž dělá nějaké veřejné představení s ohněm .
velký černý pes běží podél plotu po trávě .
motokrosař trochu letí vzduchem na skoku na závodním okruhu .
žena jede na kole po silnici a zvedá při tom přední kolo .
černý pes skáče nad vodou za frisbee , které plave poblíž lodi .
muž v černé bundě a černé čepici hraje na trumpetu .
muž v zeleném jede na snowboardu na lavičce .
indický muž sedí venku u stolu v restauraci .
tři muži v obleku dávají ruce k sobě .
malý pes v oblečku stojí na zadních nohách , aby dosáhl na visící květiny .
muž jede po schodech dolů na kole .
muž s kbelíkem a holčička v klobou jsou na pláži .
lidé jdou po městském chodníku před barem s grilem .
velký pes skáče v kašně a opodál stojí muž v černém triku a vestě .
muž na lodi oblečen v oranžových kalhotách drží provaz .
dva muži venku za jasného slunečného dne se snaží chytit nějaké ryby na jezeře .
muž stojí na lešení a barví zeď na červeno .
prodavač sedí u vystavených skleniček na trhu v asijské zemi .
dva lidé v bílých tričkách jdou po chodníku a mluví do svých telefonů .
malá dívka se zeleným náhrdelníkem běží od sítě .
umělec maluje venku .
dvě asijské děti , chlapec a dívka , stojí na podlaze vedle stromu .
lidé ve frontě se připravují nastoupit do autobusu .
dva týmy , jeden v růžovém a jeden v bílém , hrají lakros na hřišti .
žena ve žluté helmě sjíždí na laně .
černý pes plave ve vodě s tenisákem v tlamě .
tři muži jedou v tmavomodrém autě .
s vanou a vlajkami přidělanými na střeše je auto připravené ke startu rallye .
muž v modré košili hraje na trubku .
zámečník stojí ve čtvrti pro nižší-střední nebo nižší třídu , používá svářečku , kterou drží v pravé ruce , a v levé ruce drží ochranou masku .
hodně lidí stojí u fontány pod modrobílým deštníkem .
žena plete , aby se uživila ve své zemi .
pouliční prodejce narovnává zboží na stole .
tři muži stojí okolo vozíku poblíž nějakých motorek .
bankovní úředník sedí za přepážkou .
muž v červená bundě s kapucou a v bílé utěrce stojí před malbou na zdi .
muž se dívá na jeden ze svých čtyř plochých monitorů .
dva lidé jedou na kole na prašné cestě .
malá asijská dívenka se špinavým obličejem nese polštář .
dítě na břehu jezera ukazuje na něco na obloze .
pár starších kluků hraje na kytary .
muž v bílém tričku a khaki kalhotách klečí na spadlém kmenu stromu .
dva chlapci připravují malou loď a dvě dívky se na dívají z pláže .
starý muž ve středověkém oblečení drží sekeru a stojí na kopci .
tři lidé jsou na pláži , sedí nebo klečí ve vodě .
pohled skrz drátěnou mříž na muže ve žlutém , jak stojí u malé boudy .
dítě váhá , jestli má kousnout do houby .
dvě ženy v růžových tričkách a modrých džínách si povídají před obchodem s oblečením .
jízdní policista na strakatém koni si obhlíží dav .
velký černý pes hrabe hluboko do ve sněhu .
muž fotí jezero s horami v pozadí .
bruneta v modré zástěře dojí hnědé zvíře .
lidé protestují proti věkové diskriminaci na demonstraci .
dvě mladé dívky hrají basketbal , ta v bílém se snaží zaútočit a ta v červeném brání .
dáma v bikinách dělá hvězdu na pláži .
muž v hnědém tričku , šedé vestě a černé čepici hraje na basovou kytaru .
žena s blonďatými vlasy pije ze sklenice .
malý chlapec ležící na nemocničním lůžku má přikrytou nohu .
dva muži ve středních letech s hudebním vybavením spolu mluví .
pes má otevřenou tlamu , aby ukázal svoje ostré zuby .
postarší indián a indiánka ve svém příbytku .
muž leží v hromadě sněhu , která se navršila před vstupními dveřmi domu .
malá holčička se natahuje , aby si pohladila jelena .
žena s černými vlasy , který má na sobě černý top a červenou sukni někomu hrozí pěstí .
muže tlačí na kolečkovém křesle po knihovně .
dva psi si lehají do sněhu a mají otevřené tlamy .
žena s milým obličejem vytírá podlahu ve svém obýváku .
dva hokejisté jsou připraveni zahájit hru tak , že mezi ně rozhodčí hodí puk .
běžci míjí kontrolní bod ve městě .
skupina lidí tančí v klubu nebo na party v kostýmech .
dvě děti připravují na vyjížďku na slonovi .
adolescent v džínách a maskáčovém triku hraje na černou elektrickou kytaru .
osoba oblečená ve žlutém kostýmu animované postavičky na veřejnosti .
plavce v jezeře pozoruje chlapec , který sedí na zdi .
dav lidí při městské oslavě s kouřem a ohňostroji .
pes na vodítku se hrabe ve sněhu na venkově .
skupina kempuje na pustém místě .
pokladní v černém svetru počítá drobné .
chlapec si nechává strojkem holit vlasy od jiného chlapce .
obrázek teenagera , který holí hlavu svému bratrovi .
turisté si fotí budovu v číně .
keramika a auta na parkovišti s mužem v modrém , který se opírá o předek svého auta .
dva muži za kruhovým barem v místnosti plné lidí .
muž a ženy čekají , až vlak zastaví .
děti si povídají a učí se v hodině .
muž zpívá do mikrofonu , k čemuž mu hraje kapela .
zpěvák zpívá spolu s davem .
postarší žena v modrém klobouku sedí na chodníku a krájí vedle sebe něco žlutého na prkénku .
stavební dělník v černém tričku a džínách si nastavuje žebřík .
servírka v bílém tričku servíruje hostům v restauraci .
blonďatý muž v černé fleecové bundě tesá sochu .
dívka soutěžící v gymnastice předvádí náročný cvik a ohromuje tím obecenstvo .
umělec pracuje na ledové soše .
muž v modré bundě jede na spřežení se dvěma psy .
nějaká kapala nebo orchestr zkouší .
dva lidé hrají hru čelem k sobě .
několik dívek si hraje s moukou .
malá holčička hraje na hudební nástroj a zpívá do mikrofonu .
muž hraje punchout mika tysona na počítači .
muž , který vypadá , jako kdyby ho někdo uhodil , leží na zemi mezi odpadky .
výjev s člověkem odklízejícím sníh a kolemjdoucími občany v zimním prostředí .
skupina lidí v kostkovaných sukních , černých vestách a košilích s bílými límečky hrají na bubny .
krasobruslařka v červeném procvičuje své pohybu .
skupina lidí běžících maraton v zimě .
žena a chlapec na pódiu se smějí a mají za sebou stany .
muž v kabátu šéfkuchaře telefonu zatímco dva další muži v zástěrách se smějí .
holčička jde přes malý potok .
brunet v hnědém sáčku promlouvá k publiku na zábavném vystoupení .
dvě děti tančí na tanečním recitálu .
obrázek ženy a její muže a dítěte , kteří jsou po parkovišti .
lynyrd skynyrd na koncertu .
muž a žena sedí na lavičce a sledují , jak okolo jede loď .
městská ulice s mnoha čínskými znaky .
několik lidí spolu tráví čas v místnosti .
skupina muzikantů hraje hudbu na ulici .
tento muž vypadá jako , kdyby se snažil o politické prohlášení na rušné ulici .
dvě děti si hrají na venkovním hřišti .
muž sedí na schodech u domovních dveří .
muž v obleku telefonu a jde po rušné ulici .
muž v bílé zástěře a kuchařské čepici prodává maso na rušné ulici .
žena stojí a má no sobě žlutozelený šátek .
postarší asiatka má na sobě baret , sluneční brýle , žlutý šátek a kostkovaný kabát .
lidé sedí mezi nějakými sloupy a nějaká osoba jde okolo .
veterinář a veterinářka vyšetřují obrovského tygra , který leží na zemi .
dva lidé se dívají na oblečení ve výloze .
muž s batohem sedí na špinavé zemi a ukazuje na horizont .
dva muži sedí u grilu , který se leskne .
žena ve žluté bundě jde za dalšími dvěma ženami .
muž v kabátě telefonuje na ulici .
odraz chlapce na kole oblečeném v zeleném tričku ve výloze .
malá holčička se dívá přes zeď .
mladý muž si dává něco k snědku u stánku s donuty .
starý muž sedí v tácem v klíně .
afroameričan v klobouku , obleku a slunečních brýlích stojí u cihlové zdi .
tři muži si povídají před starými schody na ulici .
černí lidé nakupují v obchodě s potravinami .
muž a dvě děti přechází ulici .
muž v obleku kouří doutník , čte si noviny a jde po ulici .
skupina lidí v bílém hraje na kytary .
pes skáče , aby chytil oranžové frisbee .
několik lidí stojí na zastávce metra .
tři děti v kleci .
dva lidé stojí před budovou .
starší žena se růžovým deštníkem chrání před sluncem .
hráč baseballu dělá skluz před chytačem .
dvě ženy v modrých kostýmech sedí venku na dlažbě s betonovými a dlouhými skleněnými prvky v pozadí .
dva muži kouří venku vně parku .
muž v modrém tričku drží ceduli , která říká : &quot; ale no tak ... co je teplejší než čaj . &quot;
žena v zeleném jde rušnou ulicí .
dvě ženy sedí na stříbrných sedačkách , zatímco čekají na vlak nebo na metro ve stanici .
dav postávajících na startu maratonu .
malý chlapec nese zeleno-bílo-červenou vlajku v doprovodu ženy .
mnoho se lidí se shromáždilo , aby sledovalo dva muže , kteří hrají na nástroj a drží ceduli .
muž v pruhovaném černobílém tričku fotografuje ženu u fontány .
dva lidé na betonových lavičkách a debatují nad obědem .
voják drží kameru a ukazuje dítěti film na kameře .
muž tlačí křesla na rušné ulici .
muž venku drží mikrofon a mluví na skupinu lidí .
dva muži si povídají u zdi s graffiti .
dívka s pomalovanou tváří v oranžovém svetru stojí se svým doprovodem .
osoba stojí vedle dřevěného plotu s kvetoucími stromy opodál .
fit mladá žena kickboxuje s červeným boxovacím pytlem v tělocvičně .
pracovník stánku s limonádou otevírá krám .
muž sedí v zářivě barevném zelenomodrém boxu a za ním visí na ulici reklama .
zápas fotbalových juniorů , kde tři mladíci bojují o míč .
muž drží na ramenou dítě a lidé chodí okolo něj .
muž v zástěře stojí před jídle pod menu .
fotka blondýny na ulici ve zlatém kabátě a růžové minisukni před policejní motorkou zezadu .
několik účinkujících v bílém oblečení a vínových kloboucích jsou v řadách proti sobě .
bílá blonďatá žena , která má modrou kabelku , jede na koloběžce .
žena sedící na veřejné lavičce .
skupina lidí sedí u stolu venku , pijí a povídají si .
malá asijská holčička běží k foťáku po dlážděné ulici .
žena a čtyři děti přecházejí rušnou ulici .
ženy v domorodých kostýmech spolu zpívají .
žena mluví k malé holčičce přes stolek .
žena griluje chutně vypadající jídlo v parku .
policista pacifikuje muže jehož ruka míří do vzduchu a ostatní policisté se dívají .
muž v černém tričku zpívá do mikrofonu .
dva mladí muži v džínách a teniskách přechází městskou ulici .
dvě dívky se hrají na stromě se svým psem .
mladá žena s kabelkou se usmívá před budovou .
muž a žena jdou okolo vody k visutému mostu .
tři ženy běží bosé po písku do vody .
mimo sedí na modrém kabrioletu .
dva muži se dívají na obrazovku notebooku , jeden píše a jeden ukazuje na obrazovku .
barevný pochod vede muž s červenou vlajkou .
muž v šedé čepici a tílku v černých kraťasech stojí na rukách .
žena drží chlapce , když přechází ulici .
na obrázku je odraz muže a ženy někde na letištním terminálu .
muž šťastně zvedá promočenou ženu .
muž s bílým páskem ve slunečních brýlích drží holku za ruku .
muž jde po chodníku .
muž v prostém olivovém oblečení se drží nad zemí rukama .
fotografové připravují dokument .
muž a žena v černém stojí blízko sebe na ulici .
lidé se účastní j. p. morgan corporate challenge .
dívka a chlapec se líbají v sedě na dřevěné lavičce .
muž v plaveckých brýlích opouští bazén po schůdkách .
mladá žena oblečená v zelené a červené s mexickou vlajkou namalovanou na tváři .
cyklista v helmě letí z rampy v lese .
dvě ženy oblečené v bílém jdou po ulici na vysokých podpatcích .
indický muž prochází na své cestě na modlitbu kolem chrámu .
svalnatý černý muž v metru poslouchá ze sluchátek .
dva muži sedící venku si povídají u cedule &quot; rady zdarma . &quot;
žena v červených šatech se zrzavými vlasy stojí před výrazným barevným domem .
žena na kolečkových bruslích v přilnavém dresu .
žena v černých šatech s chlupatými klapkami na uši jde po ulici .
spoustu lidí v budově , někteří z nich vaří jídlo .
lidé zkouší z místní pekárny na místním festivalu jídla .
pohled na ulici , kterou lemují velké , čisté budovy .
žena s modrými dredy sedí na straně silnice .
muž ve dresu denver broncos a jeho přátelé mají pinkik u auta .
ženu baví klaun na místním trhu .
muž ve dlouhém modrém plášti vchází do staré kamenné budovy .
dáma v zářivé růžové košili táhne vozík s horkým jídlem .
osoba s dlouhými modrými vlasy stojí za davem lidí .
skupina lidí na pláži se drží za ruce tak , že tvoří řadu , která se dívá do vody .
muž v bílém triku hraje na ulici na housle .
mnoho lidí jde po špinavé silnice , mají na sobě letní oblečení a je slunečný den .
dva lidé ve spandexových oblecích sedí na židlích v hledišti .
černý muž s kšiltovkou sedí v autobuse .
pán vychází z veřejné prádelny .
muž v obleku a kravatě v nóbl budově na pódiu .
muž usnul na gauči .
pět mužů , všichni v bílých pláštích , stojí u jehňat na oploceném prostranství
dvě vodní vozítka , jedno červené a jedno bílé , hodně cákají ve vodě .
skupina čtyř lidí se fotí z auta .
lidé na párty na ulici .
dvě mokré dívky a za nimi žena s deštníkem .
žena v bílém drží pugét růží .
mladá dívka v &quot; pouličním oblečení &quot; a botech předvádí u jezera baletní figuru .
muž a žena stoupají po kamenném schodišti a dívají se na videokameru .
čtyři muži oblečení v tričkách a šortkách se dívají oknem na ulici pod sebou .
několik mužů stojících na alegorickém voze jedoucím davem lidí na ulici .
neudržovaný zamračený starý muž s bílými vlasy před drátěnkovým plotem .
muž bez trička dělá trik na skateboardu ve skateparku .
muž se sluchátky na hlavě prochází kolem zdi s červeno-fialovými graffiti .
dva muži v sombrerech v new yorku .
dáma ve fialovém svršku a bílé sukni se dívá na pochodující průvod .
člověk jede na motorce z kopce po hliněném kopci .
žena v žlutém s kočárkem a muž v modré košili s batohem jdou po rušné městské ulici .
muž v obývacím pokoji uvažuje , co si má sbalit na výlet .
afroamerická žena sedí u hnědého stolu , má na sobě fialové šaty , růžové boty a černé sluneční brýle .
muž shrbený na židli na chodníku pozoruje ženu .
dva muži , jeden prodává ovoce , druhý ovoce prohlíží a baví se s prodavačem .
muž a žena se objímají na ulici .
množství lidí v bílém spolu konverzují na stadionu .
hodně lidí se shromáždilo , aby se podívalo na něco , co není na fotce .
pár sedí na lavičce a povídá si , v pozadí žena venčí psa .
dvě ženy v puntíkovaných šatech jdou po chodníku .
skupina holek si hraje ve vodní fontáně na sluníčku .
lidé provádí zahradní práce na místech okolo cesty .
plešatící muž ve slunečních brýlích má na sobě zelené tričko a stojí před budovou .
bosý chlapec s modrobílým pruhovaným ručníkem stojí na pláži .
pár a dvě dívky se dívají přes průhledné zábradlí .
lidé na farmářském trhu si vybírají zemědělské produkty .
tatér aplikuje tetovací inkoust do kůže .
žena stojí proti dvěma lidem ukazuje na oblohu .
pár se prochází uličko v obchodě , který prodává kniho u umění a historii .
muž se jmenovkou sedí na židli .
muž v dálce u buddhistického kláštera .
muž balancuje s kovovou koulí na ruce .
černošský muž v bílém triku a černé kšiltovce sedí na obrubníku a píše zprávu .
chlapec v černé košili nese modrý kyblík , když jde vedle muže v bílém .
mladá tmavovlasá žena s červeným kšiltem drží otevřený deštník v davu lidí .
muž drží malé dítě , které má batůžek na zádech .
mladý muž připravuje koule na fialovém kulečníkovém stolu .
dívky sedí s rukama v klíně .
holka v černém tílku a kapsáčích vypadá , že tancuje s několika lidmi okolo .
chlapec a dívka v černých kombinézách stojí proti holčice v růžové bundě a dospělí jsou v pozadí .
muž a žena tlačí kočárky a jdou kolem lidí , kteří prodávají zboží ve stanech .
žena v pruhovaných punčocháčích je vedena jako loutka na provázcích .
stavební dělník v oranžové vestě pokládá dlažbu .
asijská žena sedí venku u stánku na trhu .
muž leží v místnosti a několik dní nic nejedl .
návěs jede po červené dlážděné cestě .
mladá žena s hnědými vlasy a tílku pořizuje snímek fotoaparátem .
osoba leží na lavičce před vodní instalací .
mladý usměvavý muž jde vedle pláže , má na sobě baseballovou čepici , modré tričko a džíny .
skupina lidí mává člověku na balkóně .
uniformovaný muž z armády trénuje německého ovčáka s ochranným rukávem .
dítě na skejtovací rampě trénuje hustý pohyby .
nějací muži na lodi vypadají , že něco probírají .
muž v letecké čepici a brýlích sedí na silnici .
lidé přecházejí ulici lemovanou stromy před budovou .
muž v šedé košili odpočívá s hlavou na stole .
muž v bílém triku a tmavých šortkách pracuje venku .
žena v černých kalhotách se dívá na svůj mobil .
mladá žena v růžovém tričku se při rodeu snaží chytit tele do lasa .
rodina stojí venku za mračného dne .
velice mladé dítě s barvou na těle a na obličeji sedí ve dřezu a hraje si s kohoutkem .
děti se točí na skleněném kolotoči .
muž a žena drží protestní cedule .
žena pracuje o víkendu na své verandě .
postarší pán v tmavomodrém sedí na lavičce na kraji ulice .
žena fotí svým foťákem .
starší muž v modrých džínách a hnědém kabátě odpočívá u oranžové budovy .
muž s rukou na hlavě sleduje reklamu bank of america .
dvě ženy sedí v noci na lavičce před obchodem .
muž v bílém tričku sedí na přepravce .
starší tetováním a motorkářskými symboly tráví chvíli na ulici .
muž sedí sám na pobřeží .
starší muž sedí venku na lavičce před transparentem , na kterém je napsáno &quot; memoria justicia sin olvido . &quot;
muž na kole v šedé bundě veze listí .
kluk s brýlemi v křiklavě žluté košili stojí na parkovišti .
dva muži jsou po špinavé cestě .
matka v modrém baretu a bodrých botách se svýma dvěma syny .
dva psi si hrají s modrozeleným míčem .
muž v zářivé mnohobarevné helmě sedí na motorce .
muž dřepí u žluté zdi .
tohle vypadá jako tržiště s několika stoly s vyskládaným zbožím .
blonďatý chlapec v modrém tričku sedí se ženou v brýlích .
muž v elegantní bílé košili hledí ženě do očí a rukou spočívá na zádech jejích černorůžových šatů .
lidé si hrají za soumraku v kašně .
čtyři kluci pózují zatímco jeden si odkládá pivo .
dáma nese zboží na hlavě na frekventované ulici .
pouliční umělec v oranžové kombinéze jede na vysoké jednokolce a dav lidí okolo se dívá .
osoba na sedí židli čelem k davu lidí .
muž čeká na příjezd vlaku na nástupišti .
tři bílí muži v tričkách skáčou do vzduchu .
zpěvák dělá stage dive .
třída potápěčů se fotí během výuky .
žena v pruhovaném tričku má založené ruce a stojí v obchodu s potravinami .
nabourané auto s mnoha hasiči , kteří se snaží prostříhat do auta .
několik lidí čeká na pokladu v obchodě , kde strop vypadá jako ve skladu .
dvě dívky hrají volejbal , jedna z nich se chystá na smeč .
starší muž vysypává něco z pytle do vody .
šest lidí v tělocvičně opravuje kola .
dva mladí asijští chlapci spolu trénují box .
žena připravuje ingredince na polévku .
dva muži v šortkách pracují na modrém kole .
muž a žena si dávají šlofíka na provizorní lodi .
muž v jakémsi pytli sjíždí z kopce pokrytého sněhem .
muž a žena si užívají večeři na párty .
voják národní gardy zpívá s dalšími vojáky národní gardy státní hymnu .
dva mladiství jdou šikmou ulicí .
žena v restauraci pije z kokosu brčkem .
žena v modré uniformě stojí a dívá se dolů .
muž v šortkách mluví s dalším mužem v modrých džínách před dřezem .
muž krmí dítě v dětské stoličce .
mladý cyklista v helmě a modrém oblečení skáče do vzduchu , když jede přes malé kopce .
mimino s růžovou čepicí leží nahé a spí .
dvě děti leží na břiše pod potrubím .
dva muži si povídají vedle telefonní budky a opodál odpočívají dělníci .
domorodá žena se věnuje řemeslné činnosti .
děti honí míč , když hrají fotbal .
dvě děti skákající venku na zastíněné červeno-modré trampolíně obklopené stromy .
dva psi na louce se dívají létající talíř , který není vidět .
bubeník a kytarista mají koncert v temném prostředí .
trojice lidí pochoduje cestou plnou sněhu .
skupina lidí vedle malé řeky uprostřed města .
žena se dívá skrz dalekohled do lesů .
malá blonďatá holčička v puntíkovaném triku &quot; koupe &quot; svého plyšáka ve dřezu .
rozcuchaný mladý muž s kroužkem v nose si čistí zuby .
lyžaři letí vzduchem , zatímco ostatní lyžaři jedu na vleku a dívají se .
tři děvčata jedou na koních , záběr je na nejmladší z nich .
rozměrnější žena si fouká vlasy fénem a šťastně se usmívá .
kuchař v kuchyni zachází s nožem .
muž stěhuje květiny a žena na něj ukazuje nějaké gesto .
žena zpívá do mikrofonu a muž v pozadí hraje na bicí .
muž s čepicí podává ulovenou rybu klukovi ve fialovém klobouku .
dělník se drží stromu .
několik lidí stojí kolem mísy , ve které jeden z nich manipuluje s hnědým objektem .
mnich na kolečkových bruslích se slunečními brýle se modlí , než udělá nějaké tríčky .
žena , která má na sobě sluneční brýle a modré tričko prodává mušle a dívá se na staršího muže v černé košili a čepici .
starý muž vytírá podlahu a žena jde směrem od foťáku .
muž s dredy si hraje s vlasy ženy , která sedí na židli na dlážděné ulici .
muž pracuje na stavbě .
muž uprostřed odehrávání červenobílomodrého volejbalového míče .
muž stojí v pojízdném stánku s jídlem a dívá se okénkem ven .
hráče baseballu s červenou helmou a bílými kalhotami honí chytač , když běží na domácí metu .
muž v oranžovém úboru venku zametá .
muž ve fialovém tričku pracuje v biologické laboratoři .
muž vede dva malé poníky na procházku v parku .
dvě ženy , jedna z německa a jedna z číny , zápasí na matraci na soutěži .
muž a žena spí na lavičce .
muž a žena sedí na zemi před zavazadly .
obsluha rikši čeká na dalšího zákazníka .
dvě dívky sedí u stolu a pracují na řemeslných projektech .
muž běží ve sněhu za pomocí sněžnic .
tanečník v červeném obleku skáče do vzduchu .
muž sedí v zaparkované hygienické dodávce .
vousatý muž v těžké bundě sedí v rohu s papírovým kelímkem .
muž na skateboardu používá prázdný bazén jako rampu za velmi slunečného dne .
muž ve velkém klobouku v křoví .
detail dětské tváře jak jí modré , srdcovité lízátko .
muž a žena pracují na výměně duše u kola .
malý chlapec ukazuje svůj hnědozelený korálkový náhrdelník .
muž v šedém tričku pracuje s měchem , aby rozfoukal oheň v cihlové peci v dřevěném přístřešku .
žena strojí před stromy a směje se .
někdo v asijském kostýmu sedí a drží meč .
mladý hráč amerického fotbalu připravuje míč ke kopu .
chlápek ve jasně zelené bundě s kapucí přechází silnici a dívá se na nehodu auto a kola .
mladý muž se chystá kopnout do fotbalového míče .
závodní běžkyně běží svůj první sprint v soutěži .
dva muži , jeden v modrém a jeden v červeném , boxují .
skupina přátel se rozvalila na zem a baví se spolu .
stojící muž drží mikrofon před muže , který drží kytaru .
dívka na kolečkových bruslích bruslí s ostatními .
žena si v obchodě bere pytel ledu .
dva motorkáři závodí a předhání se v zatáčce .
muž stojí sám na chodníku a upracuje si čepici .
beznohý muž jde s jiným mužem , který se přihlásil do maratonu .
několik lidé se srazilo při fotbalovém zápase .
dva lidé , jeden oblečený jako jeptiška a druhý v tričku roger smith , běží závod kolek diváků v zalesněné oblasti .
tři muži na koních při závodu .
muž tmavé pleti s bílými šortkami a černým tílkem obrací svůj skateboard na betonovém povrchu obklopeném výškovými budovami a palmami .
muž , který má na sobě mikinu s kapucí sedí u fontány a dívá se na lidi ve městě .
plavci stojí na různých úrovních velkého komplexu skokanských můstků v místnosti s mytologickými výjevy namalovanými na zdech .
malý indický chlapec sedí a přemýšlí o své budoucnosti .
chlapec s kapucí hází předmět do špinavého bazénu .
muži v barevných kostýmech při představení .
dva boxeři jsou připravení na souboj a publikum s očekáváním přihlíží .
děti hrají sport na hřišti .
umělkyně zpívá a hraje na kytaru před mikrofonem .
chlapci soutěží v bojovém umění .
skupina černochů v oranžových tričkách vystupuje před oploceným parkem .
školní dívky v uniformách pochodují na přehlídce a hrají na nástroje , co vypadá jako flétna .
muž plní drůbež přísadami z modré misky .
kluk skáče z postele v karatistickém kopu .
mimino v chodítku a stojící chlapec obklopeni hračkami .
lidé shromáždění u stolu hrají hru jenga .
muž s plnovousem a postarší žena jí z jedné misky .
mladý muž skateboarduje na betonové zdi .
lidé jedou na loďce na jezeře se sluncem a mraky v dálce .
dva muži v kimonu trénují bojové umění .
chlapecká kapela a vůbec k sobě nepasují , měl by poslat poznámku .
skupina jezdců v motokárách závodí na trati .
člověk oblečený v zimním oblečení pózuje se sněhulákem , obklopený zasněženou krajinou .
muž prezentuje před publikem .
muž ve středním věku zavazuje koleno mladému hráči amerického fotbalu , jenž sedí na trenérském stolu .
potetovaný muž v kombinéze drží mikrofon na pódiu .
malá dívka si hraje s drobným elektrickým obvodem se třemi žárovkami a baterií .
muž v modré helmě se na kole připojuje do provozu .
hodně mladých dospělých soustředěně zírá do svých počítačů , když soutěží v počítačové hře .
malý chlapec v zeleném žongluje na parkovišti .
malá holčička v puntíkovaných šatech se otáčí na ženu v černých šatech .
muž spravuje motor z lodi u vody .
tenisový zápas , který se hraje uprostřed stadionu .
dítě na snowboardu zastavuje .
hraje se kopaná a dva muži se snaží dostihnout míč dříve než ten druhý .
mladé ženy a děti ve vesnici , jedna z nich je otočená k fotografovi .
batole v zeleném tričku si čistí zuby žlutým kartáčkem a maminka na něj dohlíží .
muž na vozíku v červeném běžeckém oděvu nese pochodeň .
syn a jeho rodiče se fotí v kostele .
tři muži závodí v běhu přes překážky .
dva muži pozorují dalšího , jak dokončuje práci s mokrým betonem .
voják pozoruje horskou krajinu dalekohledem .
skupina hochů závodí za sněžného dne .
muž skáče přes švihadlo a dívá se na něj dav lidí .
malý chlapec a dívka se společně smějí , když dívka ukazuje gesto rukou .
dva muži z různých týmů honí fotbalový míč .
cyklista ve žlutém tričku předvádí ve vzduchu neuvěřitelný tríček .
dvě kickboxerky , jedna ve fialové sportovní podprsence , spolu bojují v aréně .
dva muži na rychlých motorkách sviští zatáčkou závodního okruhu .
dva muži brání dalšího muže , když hrají basketbal za soumraku .
muž v jezdeckých botách a helmě jede na bílém koni a kůň skáče přes překážku .
skupina mužů v kostýmech hraje na hudbení nástroje .
muž a ženy procházejí přepravky plné desek nebo obrazů na prodej .
závodní katamarán má zvednutý trup ve vodě .
skupina námořníku jde s americkými vlajkami a dalšími vojenskými vlajkami .
muž drží skleničku před fotografem .
jeden muž hraje na kytaru na pódiu se světly v pozadí .
čtyři děti se hrají s prázdnými kanystry .
skupina dělníků poslouchá kolegovy instrukce .
zednář řídící velký zelený traktor jede v průvodu po silnici .
tři psi si hrají ve vodě .
muž hraje na buben a malý kluk na svůj vlastní , malý buben .
skupina dívek hraje hru na koních .
muž se dívá na ženu , jak s úsměvem střílí z pistole na střelnici .
vedoucí cyklista šlape jako o život , zatímco soupeřící země jsou těsně za ním .
tým hráčů kopané v hloučku probírá vážné věci .
skupina lidí ve fialových tričkách a světle hnědých kalhotách jdou stejným směrem .
muž ve světlé košili hraje na trumpetu .
chlápek s džínovými šortkami dělá ve skate parku triky na kole .
matka a dcera mají na sobě kostýmy z alenky v říší divů a pózují na fotku .
malý chlapec vrtá díru do kusu dřeva .
dva cyklické spolu závodí za špinavé dráze .
někdo hází frisbee dívce , zatímco si o něj , zdá se , říká druhá dívka .
ortodontista pracuje s pacientem a muž drží světlo .
dva lidé jí hamburgery na venkovních židlích a třetí pije limonádu z plechovky .
dva cyklisté jedou po ulici okolo lidí a povídají si .
na bowlingové drží muž v černém tričku bowlingovou kouli a dívá se na dráhu .
dva muži v černém oděvu s modrým a červeným motýlkem vystupují před lidmi .
dva muži , jeden černý jeden bílý , stojí venku a hrají na kytary a zpívají do mikrofonů .
kickboxer přistává kolenem do tváře protivníka .
tři lidé běží závod na červené běžecké dráze .
fotbalisté mají potíže dostat se přes pevnou linii .
několik mužů se modlí , když stojí u stolu plného jídla .
dvě indická děvčátka ve formálních kostýmech nadšeně předvádí rituální tanec .
tři děti stojí u sebe u vysokého modrého dřevěného sloupu .
skupina lidí běží .
ženy jsou po pláži , nesou prkna a ploutve .
chlapec sedí na skále a dívá se do údolí pod sebou .
žena stojí na vysokém útesu na jedné noze a dívá se přes řeku .
bruneta stojí na chodníku a dívá se na silnici .
skupina tří přátel doma konverzuje .
dva číňané stojí u tabule .
osoba s modrými džínami a červenou mikinou jde za roh cihlové zdi .
rolníci se věnují zemědělství v průběhu dne .
nějaký karneval , muž dělá cukrovou vatu .
hodně policistů stojí před autobusem .
starší bělovlasá žena se dívá své poklady a dívá se přes brýle .
dva muži stojí ve venkovních telefonních budkách .
dvě ženy v červeném oblečení a muž vycházející z mobilního wc .
