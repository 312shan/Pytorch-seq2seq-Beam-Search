muž v oranžovém klobouku na něco zírá .
bostonský teriér běží po zářivě zelené trávě před bílým plotem .
dívka v uniformě na karate , která předním kopem láme dřívko .
pět lidí v zimních bundách a s helmami stojí ve sněhu , se zasněženými skútry v pozadí .
lidé opravují střechu domu .
muž ve světlém oblečení fotografuje skupinu mužů v tmavých oblecích a v kloboucích stojících okolo ženy oblečené v šatech bez ramínek .
skupina lidí stojící před iglú .
chlapec v červeném dresu se snaží , aby se nevyoutoval na domácí metě , zatímco se chytač snaží chytit míček .
chlapec pracující na stavbě .
muž ve vestě sedí na židli a drží časopisy .
matka a její mladý syn užívající si krásný den venku .
muži hrající volejbal , jeden hráč minul míč , ale ruce má stále ve vzduchu .
žena , která drží misku s jídlem v kuchyni .
muž sedící u stolu v jeho domě používá nářadí .
tři lidi sedí v jeskyni .
dívka v džínových šatech , která jde po kladině .
blondýna drží ruku chlápka v písku .
žena v šedém svetru a černé kšiltovce stojí ve frontě v obchodě .
osoba v pruhovaném triku leze po horách .
dva muži předstírají , že jsou sochy , zatímco se na ně dívají ženy .
lidé stojící před budovou .
teenager hraje na svoji trumpetu na utkání na hřišti .
žena dělá salto na trampolíně na pláži .
muž stojí u automatů s videohrami v baru .
žena používá vrtačku , zatímco si ji další muž fotí .
žena v růžovém svetr a zástěře , která čistí stůl houbičkou .
muž řezající větve stromů .
skupina asijských chlapců čeká až se jim ugriluje maso .
ženy v národních krojích předvádějí domorodý život .
jeden muž drží hlavu druhému muži a chystá se jej uhodit do obličeje .
šest lidí jedoucích na horských kolech uprostřed džungle .
dvě blonďaté dívky sedí na římse na přeplněném náměstí .
dítě se cachtá ve vodě
tři lidé sedí u piknikového stolu venku před budovou pomalovanou britskou vlajkou .
3 chlapci v plavkách stojí na molu .
zaměstnanec podává ženě tašku zatímco ona si prohlíží ryby na ledě na pouličním trhu .
krásná žena hraje na cembalo .
venku před budovou stojí strážník v uniformě a dívá se na kameru zpoza plotu .
mladá dáma hledí na pizzu .
muž bez trička a v šortkách rybaří , zatímco stojí na nějakých kamenech .
dívka v záchranné vestě pluje po vodě .
muž v uniformě a muž v modré košili stojí před kamionem .
lidé sedí uvnitř vlaku .
dítě se v lese houpe a má nohy do vzduchu .
muž v červeném tričku vchází do podniku .
dva muži , kteří na sobě mají bermudové plavky , skáčou na přiměřeně zalidněné pláži .
batole vaří s jinou osobou .
otec a dvě děti před jejich domem pracují na zahradě a na příklad používají motyku a sázejí strom .
muž vaří na sporáku jídlo .
muž v džínách na pláži si hraje s červeným míčem .
lidé , kteří jdou po chodníku vedle řady obchodů .
wakeboarder předvádí salto během toho , co je vlečen ve velké rychlosti .
velká skupina lidí zaplňuje ulici .
muž na lanovce vedoucí do vody .
žena v džínách jde kolem autobusu , na němž je vyobrazená reklama se ženou , která se dívá přes své sluneční brýle .
muž v růžovém triku sedí na trávě a ve vzduch je balon .
auto zaparkované na pláži .
dva muži v černém ve městě
muž ve žlutých kalhotách zvedá nahoru ruce .
dva muži , kteří mají kšiltovky a vycházkové hole , se prochází u vody při západu slunce .
roztlečkávačský tým předvádí sestavu na židlích .
chlapec hraje dámu s dospělým , který není v záběru zatímco je pozoruje dívka .
dav lidí se baví ve veřejném parku .
muž , který sedí na lavičce , drží svého psa a dívá se na vodu .
chlapec a jeho mladší bratr , kteří si spolu hrají na hřišti .
žena v modrém nahlíží do kožené taštičky , sedí na lavičce za slunečného odpoledne , zatímco kolem ní prochází lidé a za ní projíždí limuzína .
hnědý pes stojí na pískové pláži .
žena sedí s košíkem oblečení a je obklopená oblečením .
muž griluje vzadu na dvorku .
žena zpívá v klubu s kytaristou za ní .
kytarista , který vystupuje v nočním klubu s červenou kytarou .
dítě sedí na zahradním lehátku se kouká na kameru .
dvě ženy a tři muži se dívají na oceán .
interpretka s houslemi hraje na ulici zatímco ji pozoruje žena s modrou kytarou .
mladá dívka plave v bazénu .
několik dětí se venku připravuje na bitvu v přetahování o lano .
tři náctiletí dovádějí v metru .
hnědý pes s jazykem visícím ven kráčí v trávě .
lidé sedící na trávě mimo budovu , kteří odpočívají .
muž bez trička zírá do dálky zatímco tři ženy procházejí okolo davu sedícího na zahrádce restaurace .
dva chlapci nandávají ovoce na kolo .
muž v černém tričku , čepici a džínách hraje na vzhůru nohama položený žlutý kbelík .
mladá umělkyně maluje obraz ženy na zeď .
dvě spoluhráčky týmu usa skáčou do vzduchu a u toho si plácají a kolem nich jsou dvě další spoluhráčky .
muž míchá hrnec s tekutinou v této kuchyni .
chlapec wakeboarduje na jezeře .
muž , který pracuje u stánku s párky v rohlíku .
velká skupina lidí různého věku a pohlaví sedí venku pohromadě .
blonďatá žena nalévá drinky na baru .
malé dítě v modrobílém tričku radostně drží hračku žlutého plastového aligátora .
žena s růžovými vlasy oblečená v černém mluví s mužem .
muž v japonském kuchařském oděvu připravuje jídlo pro dvě osoby .
dívka přeskakuje přes řeku z kamene na kámen .
dělník s krabicí nářadí klečí vedle dvou žen .
starší muž otevírá svou náruč a vypadá zmateně .
dítě v karate obleku trénuje jakýsi pohyb
tři lidé ve stejně barevných vestách jsou venku .
žena fotografuje dítě s růžovým kloboučkem , zatímco jej muž nese .
skupina převážně asijských dětí sedících v kabinách na modrých židlích .
malý chlapec ve fotbalovém dresu si brečí do dlaní .
šťastná žena připravuje v kavárně občerstvení .
dělník řídí těžké vybavení na stavbě .
žena se rozebíhá po tom , co trefila míček v ženském softballe , chytačka se staví na nohy .
muž v pracovní uniformě podává nástroj další osobě .
skupina lidí leze v chladném počasí .
horolezec v modré helmě , který se chystá slaňovat ze skály .
muž dělá stojku na vršku zakulacené sochy .
dítě sedí v restauraci a drží si papírovou masku před obličejem .
hnědý pes brodící se v jezeru , aby aportoval klacek .
matka učí své dva chlapce rybařit na skalnatém pobřeží u velmi modré vody .
malé dítě se prochází vedle červených transparentů .
dívka sedí s mladším chlapcem na ozdobeném kole , zatímco další dívka je fotografuje .
černý pes aportuje balonek ve vodě .
muž v bílých kalhotech a modrém tričku kope do žlutého boxovacího pytle .
dva indičtí muži se účastní ceremonie .
chlapec s odřeným nosem a popsanýma rukama stojí ve videopůjčovně .
dvě siluety lidí při západu slunce pádlují na kánoi po oceánu .
lidé stojí v přeplněném metru a skrze okno je vidět na peron .
muž leze po zdi s ohněm v ruce
dva hnědí psi běží sněhem .
fotografie z pódia malé kapely účinkující pro divadelní publikum .
dítě ve vánočním oblečku se dívá na kameru .
muž sedí u monitoru od počítače .
tato žena slyšela srandovní vtip a směje se .
lidé uvnitř budovy , jeden z nich fotografuje .
čtyři bílí psi s náhubky skáčou přes červenou zeď .
žena v modrém triku drží dítě .
dva lidé sedí na pruhovaných lehátkách ve vodě a u toho rybaří .
stará žena pracuje na tkalcovském stavu a vyrábí látku .
na popředí stojí chlapec a dívá se na lidi na náměstí .
muž v modrém kabátu , který popadl mladého chlapce za rameno .
tři hnědí psi skáčou na ženu v modrém .
chlapec visí z okna projíždějícího taxi
muž v šedém triku přeskakuje přes vrchol písečné duny v poušti .
dítě ve žlutém tričku skáče nahoru a dolů .
dělník ve žluté bundě je vyzdvižen vysoko nahoru k opravě budovy .
muž v brazílii neformálně promlouvá k mladým dospělým .
spousta pivních píp na baru s vánočním osvětlením na stropě .
muž se slaňuje dolů z útesu nad oceánem .
muž v černím kráčí ke svému náklaďáku ve sněhu .
foxteriér skáče po míčku .
policistka v čepici a tmavě modré uniformě se usmívá a má na sobě sluneční brýle před obchodem .
rodina na procházce v parku .
muž v zelené helmě a žluté bezpečnostní vestě se mračí .
dítě s růžovými provázky na hlavě tancuje a je obklopeno konfetami a balonky .
pes se spláclým čumákem něco čuchá na břehu řeky .
muž připravuje místní stánek k dennímu obchodu .
muž v červeném tričku se chystá jíst tacos .
mladá žena v bílém drží tenisovou raketu
chlapec v červeném tričku kope do písku díru žlutou lopatkou .
individuum v růžové bundě nečinně sedí na dřevěné lavičce .
muž v bílé košili se dívá ven z okna s kovovou konstrukcí .
žena drží malou bílou sošku .
šest dětí bez triček si hrají v přírodní vodě a cákají kolem sebe .
dva lidé jedou na kolech přes horskou krajinu .
dívka skákající přes švihadlo na chodníku vedle garáží .
muž mající na sobě oranžové tričko a helmu .
malý chlapec si hraje s plastovými kostičkami , auty a zvířátky a pozorně na něj dohlíží dospělá osoba .
malá dívka otevírá vánoční dárek .
žena v modrém nastavuje fotoaparát před dalšími dvěma ženami .
malá dívka odpočívá na pohodlné sedačce .
hnědočerný pes běžící po lesní cestě .
dva psi si hrají u stromu .
námořník kráčí po schodech , má na sobě černý kabát a kalhoty a fotoaparát je zaměřený na psa
dva muži v zeleném připravují jídlo v restauraci .
muž oblečený v černé kůži a kovbojském klobouku prochází okolo renesančního festivalu .
pes běhá venku se žlutou hračkou .
pes v pokrývce utíká sněhem .
rodina si hraje na pláži se svým psem .
žena a dítě se objímají a dítě ochutnává , co udělali .
dva muži a žena stojí venku .
skupina mužů táhne z vody loď za pomocí kmenů .
muž pije ze sklenice na víno zatímco si čte noviny .
muž v černém hraje na piano .
mladý chlapec oblečený v modrém dresu a žlutých šortkách hraje fotbal .
muž stojí na kamenné konstrukci a ruce má roztažené jako pták .
pes pije vodu venku na trávníku .
dvě ženy v tílkách se dívají na kameru .
muž sedí na holičském křesle a je připraven k holení .
dítě v zelených botách si hraje v bahnité louži .
muž používá motorovou pilu k nařezání dřeva .
muž sedící u piknikového stolu , na kterém je tác a upité pivo .
chlapec v černém triku a modrých džínách drží červenou baseballovou pálku .
muž , který má tmavě hnědé vlasy , vousy , brýle a na sobě hawajskou košili sedí na trávě .
psi utíkají po závodní dráze .
osvětlovač s klanovými tetováními míří reflektorem přes balkon .
dva němečtí ovčáci na sebe vrčí .
toto je skupina postávajících lidí na jakési události .
hnědobílý pes chytá hračku .
muž s bílými vlasy hraje na akordeon mezi budovami .
žena s hnědými vlasy sedí na lavičce před kavárnou .
muž vedle cyklistické stezky hraje na panovu flétnu .
dvě děti balancují na kládě a drží lano .
muž na motorce předvádí trik na závodní dráze .
mladá žena s fialovou látkou zakrývající její obličej odpočívá na dřevěném mole .
žena v hnědém tričku sedí na zářivé červené lavičce .
pes kráčí po kmeni přes malou řeku .
mladý muž má na sobě bílé tričko a zelenočerní kraťasy a stojí na patníku .
skupina lidí je celá schovaná pod deštníky .
muž inzeruje obrovskou cedulí přidělanou na kolo .
muž hází klacek do vody zatímco ho pozorují dva psi .
skupina starších hrají na hudební nástroje pod stanem u vody .
pohled na přeplněnou ulici .
mladá blonďatá žena drží bílý provaz za slunečného dne .
dva lidé v modrých tričkách stojí venku s megafonem .
černý pes , který se noří do bazénu .
kovboj jede na hřbetu divokého koně během soutěže .
pracovníci na železniční trati provádějí údržbu kolejiště .
dělník v oranžové vestě používá lopatu .
dva stavebníci o něčem diskutují na stavbě .
tři muži jdou nahoru do kopce .
asiatka v květovaných svatebních šatech pózuje na mostě poblíž jejích družiček .
mladý muž ladí svou kytaru v kuchyni .
tři chlapci si hrají s houbami a kyblíky s vodou .
tři dělníci opravují chodník .
lidé chladící se v lese vedle kanoí .
sbor je shromážděn v kostele .
skupina mladých náctiletých v noci skáče a na kameru dělají vtipné pózy .
dva chlápci na kajacích na potoce , jeden oranžový , druhý modrý .
dva dělníci roztírají cement po cihlách budovy .
dáma v načervenalém svetru a džínách sedí s rukama na levém koleni
dva účinkující rádoby bojují před diváky , kteří je pozorně sledují .
voják odpočívá a čeká na letišti .
muž ve žlutém kabátě se snaží rozdělat oheň a chlapec v parce přihlíží .
muž a chlapec na skalnaté pláži .
žena na lodi jménem el corazon spouští do vody černé závaží .
chlapec sedí a dívá se skrze mikroskop .
malá bosá holčička v růžových šatech skáče po venku .
mnoho lidí sedí venku okolo stanu .
mladík s černým tričkem s nápisem &quot; asian pacific 2007 &quot; hraje sedíc na bubny .
muž prodávající předměty poblíž cesty vedoucí k velké hoře kaňonu .
dívka ve žlutém se směje dívce v oranžovém , zatímco je pozoruje dívka v modrém .
pes , který skáče přes venkovní překážku .
pes s černým obojkem se válí v hlíně a uschlém listí .
dva hnědí psi si hrají drsným způsobem .
muž s knírem a bradkou drží obří pánev , ze které šlehají plameny .
muž mající na sobě dobové oblečení zvoní zvoncem .
muž v černé košili rybaří na skalnatém pobřeží .
dva psi se k sobě tulí čumáky .
dva lidé se zastavují k rozhovoru na chodníku a kolem projíždí auto .
číňan , který sedí a čeká na zákazníky .
zaparkovaná auta a za nimi školní autobus .
dvě ženy mají na sobě obdobná trička a kráčí doleva .
malé dítě má na sobě oranžovou záchrannou vestu a vesluje na modrém kajaku po vodě .
lidé , kteří jdou po cestě v parku plném stromů .
tři mladí lidé si povídají v davu lidí a ta žena vypadá rozrušeně .
žena a dítě před vchodovými dveřmi jejich malebného domova .
černý muž a jeho dva bílí kamarádi si k sobě dávají blízko hlavy .
dívka v maskáčích sedí na střeše hummera .
světle hnědý pes běží nahoru .
chlapec pózuje s velkým zeleným hmyzem na nose .
plešatý muž , který předvádí , jak vysoko vyskočí jeho černohnědý pes .
dav na rušné třídě za bílého dne .
anglický chrt s košíkem ve žlutočerném běží po závodní dráze .
muž má na sobě sandále a sedí na chodníku u tašek .
muž a žena sedí u plotu a povídají si .
dítě si prohlíží kávovary uvnitř obchodu .
muž pije ze žlutého kelímku a kolem jsou lidé během rušné události
chlapec se opírá o auto s květinami na kapotě .
žena v květovaných šatech mluví před dodávkou s dítětem .
muž během jeho svatebního dne .
mladá žena v černém triku a džínách zametá .
žena v klobouku leze po útesu poblíž velké masy vody .
velký černý pudl běžící po trávníku s hračkou v tlamě .
chlapec v šortkách dělá trik na skateboardu .
malý chlapec oblečený v červených kalhotách stojí na ulici .
žena textuje na mobilu a je obklopena deštníky .
osm mužů hrajících na nástroje na podiu , s kytaristou , který je zvýrazněn světly .
muž v oranžovém obleku a ladící helmě pomáhá s modrou hadicí
muž a dvě dívky se chlubí rybou zatímco drží rybářské pruty před vodním útvarem .
muž v červeném triku sledující psa na agility dráze .
chlapec mající na sobě červenobílé plavecké bermudy skáče pozadu do krásného bazénu .
asijská žena si přišpendluje vlasy dozadu .
starší žena a malé dítě v růžovém si hrají s pestrobarevnými kostkami .
malý černý pes skáče přes branky
hnědovlasý muž v zelené košili hraje venku na trumpetu .
muž mluví do telefonu s nohama nahoru .
skupina dětí sedí na modré matraci zatímco jedí z misek .
černý chlapec sedí v písku .
malý pes pronásleduje dva velké psy hrající si na poli .
lidé sedí v kruhu před velkou budovou .
jeden pes , který skáče pro softballový míček , zatímco druhý jej sleduje .
blonďaté dítě se houpe na houpačce .
jeden muž a dvě ženy diskutují u bílého vína
asiat vaří jídlo venku .
hnědý pes chytá zelený létající talíř .
fanoušci povzbuzují během toho , co kapela hraje píseň .
malý chlapec stojí u písečné sochy pyramidy .
tři mladé děti se procházejí po travnaté zahradě .
muž tluče na umělecké dílo posazené na vozíku .
muž na kole jede po hoře .
chlapec v modrobílých holínkách běží po hlíně .
žena v oranžové bundě sedí na lavičce .
muž předvádějící trik na skateboardu .
muž v obleku na bojové umění ve výskoku .
žena na chodníku prodává pytlíky ovoce .
dva fotbalové týmy na hřišti .
dítě v modrém tričku skákající z lavičky .
brankář ve žlutém poli chrání bránu .
skupina mladých lidí pije panáky v mexickém prostředí .
mladý muž jede na skateboardu po růžovém zábradlí .
malý chlapec skáče z palandy na menší postel .
dva lidé na sobě mají zvláštní kostýmy mimozemšťanů , jeden modrý , jeden fialový a stojí na silnici .
muž běží v modrém triku , na kterém je přilepené číslo .
asijská pracovnice v továrně pózuje na kameru .
muž který vypadá , jako když běží maraton , zvedá nahoru oba palce .
basketbaloví hráči střílí na bránu během hry .
hráč amerického fotbalu má na sobě oranžový dres , usmívá se a drží míč .
dva sjezdoví skateboardisté vybírají zatáčku , zatímco je ostatní sledují .
družstvo v bílozlatém na kraji hřiště na americký fotbal .
malá dívka tlačí svou koloběžku po travnaté ploše obehnané stromy .
skupina asijských dětí oblečených v bílých tričkách a čepicích předvádí zatímco se na ně dav kouká .
chodci jdoucí po ulici se dívají na dítě v kartonové krabici .
hnědý pes běží po písečné pláži .
dva muži ve vojenských uniformách stojí vedle ženy .
dalajláma během recepece , na kterou si účastnici přinesli karafiáty , slunečníky a modlitební praporky .
cyklista skáče na překážku .
pár sedící na bílých zahradních židlích se usmívá na kameru .
mladé děti jedou v malém vláčku .
surfař v modrých plavkách jedoucí na vlnách .
chlapec skáče na svého bratra fotbalistu .
dva mladí muži opačných fotbalových týmů soupeří o balon na fotbalovém hřišti .
lidé kráčí po dlážděném svahu obklopeném čínskými prodavači .
malý chlapec v bílých kalhotech skáče z gauče .
chlapec v oranžovém tričku vysypává z pytlíku lego .
žena má na sobě hnědé sandály , modré džíny a bílé triko a drží dítě pod stromem .
tři lidé se usmívají a drží cedule s politickými nápisy .
strážník stojí na silnici vedle auta .
dva muži v čepicích .
chlapec ve vzduchu se snaží kopnout do fotbalového míče
mladý chlapec v modré čepici má skloněnou hlavu .
zrzavý muž s dredy sedí a hraje na akustickou kytaru .
muži , který jí sendvič , s jeho dcerou na klíně .
afroamerické dítě drží něco , na co jsou ostatní na té fotce pyšni .
žena řídí dav lidí za pomocí megafonu .
diváci v převlecích se koukají na policistu v uniformě , který řeční a muž v obleku drží mísu s ovocem .
dav v baru .
dívka v bílém a dívka v zeleném jdou okolo modré myčky na auta .
muž používá elektronické vybavení .
osoba surfující skrze lámající se vlnu oceánu .
voják něco vyšetřuje .
nevěsta a ženich se líbají pod nevěstiným závojem .
pořádková policie stojí v pozadí zatímco mladý muž s červeným šátkem zakrývajícím obličej kráčí .
černobílý pes skáče přes překážky na soutěži
žena mající na sobě svetr si čte doma knihu .
několik náctiletých se dívá přes zábradlí v tmavé místnosti .
muž v bílém triku právě leze na skálu .
náctiletý chlapec se protahuje v kuchyni a je mu vidět kus břicha .
lidé drží různé druhy paliček na buben nad různými druhy bubnů .
tři farmáři sklízí rýži na rýžovém poli .
dvě ženy a muž se koukají na knihu .
nohy tří dětí zobrazeny kousek od nepořádku způsobeným stříkacími party špagetami ve spreji .
kuchař pózuje na kameru zatímco vaří .
mnoho lidí na ulici protestuje proti užívání uhlí v elektrárnách .
teenager skáče z kopce na kole .
malá holčička běží po pobřeží .
bílá kachna ve vodě mává křídly .
zdá se , že dva muži konverzují , stojí za zády ke kamionu a před jakýmsi kovovým předmětem , zatímco čtyři lidé stojí kolem nich .
žena v růžové sukni drží miminko .
hokejový hráč ve žlutém dresu chrání bránu .
muž jde okolo velkého nápisu e.s.e. electronics .
tři chlapci mají na sobě zelené košile a světle hnědé kalhoty a pózují na vrchu klouzačky .
muž tancuje se psem mezi nohama .
bílý pes běží v mělké vodě .
oregonští bubeníci kráčí s kapelou .
skupina dětí si hraje na oploceném dvorku a dospělý se na ně dívá .
skupina žen spolu hraje na hudební nástroje .
malá dívka ve fialových kostkovaných šatech leží na podlaze a pláče .
muž se šedivějícími vlasy si holí vousy .
dva černí psi , jedno černé štěňátko a bílý pes ve sněhu .
muž v basketbalovém dresu miami skáče do střelby .
žena sedí venku před domem s modrými dveřmi a užívá si vzduchu .
děti sedí na mužovi v kostýmu banána .
šedobílý pes skáče přes stojatou vodu v písku .
dav lidí shromážděn za deště okolo vodní fontány v parku .
několik starších mužů , někteří v tradičních pokrývkách hlavy se scházejí na rohu ulice .
mladý pes vypadající jako lassie je ve sněhu .
fotbalový hráč mající na sobě zlatý dres blokuje balon hráči soupeřícího týmu .
žena v černém triku plete z fialové příze .
čtyři ženy asijského rodu na sobě mají zlaté šaty při baletění na špičkách .
osoba hraje na jedinečný nástroj .
žena v černém sportovním oblečení s číslem 1103 na dresu běží přes trávu .
dítě na běžkách má na sobě číslo 93 .
starší muž a malá dívka spolu začínají stavět puzzle .
filmový štáb natáčí mladého afrického chlapce ve žlutém tričku .
osvětlený most s cyklistou a auty .
muž na býkovi v býčí ohradě .
chlapec skáče , aby strefil tenisový míček se svou raketou .
děti lezou na zeď a dva další lidé na ně koukají .
lidé procházející se po univerzitním kampus s palmami v pozadí .
malá dívka nakopává předmět na hodině karate .
dva muži se snaží vyhoupnout z vody nahoru na chodník udělaný z pneumatik .
dva muži dělají breakdance a dav se na ně dívá .
profesionálně oblečená žena stojí u stupínku a debatuje či diskutuje o něčem důležitém .
žena leží na pohovce a směje se .
prachová podlaha je zametána jednou bílou a jednou černou ženou .
jelen skáče přes plot .
tři psi si spolu hrají venku na poli .
dvě malé děti jsou na písku .
usmívající se malý chlapeček si hraje v listí poblíž kachen .
tito čtyři lidé stojí venku se třemi psy .
průvodce ukazuje směrem k dalším atrakcím při návštěvě májských trosek .
dívka má na sobě tričko s nápisem &quot; radio &quot; a má otevřenou pusu
skupina kmene plní vodní kanystry v poušti .
muž stojící na ulici .
hejno ptáků letí pryč se žrádlem v zobácích .
dva muži jedou na vozíku taženém mulou přes zemědělskou půdu .
dva lidé stojí na vrcholu hory .
mladá dívka se baví tím , že dělá anděla ve sněhu .
tři muži smějící se na kameru ukazují svoje svaly .
osoba píše na tabuli v prázdné třídě .
muž v černé košili sedí u stolu s před sebou otevřeným apple laptopem .
čtyři lidé relaxují na travnatém vršku s výhledem na skalnaté údolí .
chlapec na skateboardu skáče do vzduchu podél kolejiště .
muž v oranžové košili hrající tenis .
pes v červeném obojku cení zuby na psa v modrém obojku .
chlapec si venku užívá letní den .
dělník v oranžovém obleku klečí a prohlíží nějaké strojní zařízení .
muži v kovbojských kloboucích stojí okolo rodea .
dva psi ve sněhu a jeden z nich má něco v hubě .
zaměstnanec si dává pauzu od práce a pije nápoj
béžový pes běží za bílým psem , který drží žlutou hračku .
hokejový hráč v bílém dresu s holí
muž má na sobě bílé triko a zlaté hodinky a ovládá desku s plošnými spoji .
černý kůň strká hlavu skrze plot , aby dosáhl na trávu .
feťák závislý na cracku předstírá , že si zahřívá ruce , ale doopravdy kouří crack .
dva chlápci a žena se smějí .
dítě se naklání přes výstavku s modrým a žlutým plastem , zatímco dospělý přihlíží .
černobílý pes běžící pro vyfouknutý balon ve sněhu .
malá dívka stojí vedlé světlé kočky na kuchyňské lince .
dvě děti si hrají na hřišti .
tenisový hráč v zeleně pruhovaném tričku si drží ruku před pusou .
chlapec v červených plavkách si hraje ve vodě .
dítě mající na sobě červenou bundu a čepici drží velký kus sněhu .
dva strážníci v oranžových vestách stojí venku před bílým stanem s diváky .
dva lidé stojí na zemi vedle stromu .
dva muži sedí a povídají si poblíž kamenné budovy .
hnědovlasé dítě s brýlemi drží blonďaté dítě v červeném svetru a žlutých botách .
černobílý pes si hraje s bílým míčkem .
dva lidé se líbají na chodníku před limuzínou , zatímco okolo chodí lidé .
žena hraje volejbal .
dva velcí psi se rvou na hliněném poli .
hnědý pes skáče přes překážku .
muž v pruhovaném triku kouří cigaretu na ulici
malá holčička na svém klíně drží malého chlapce .
muž se snaží jet na velmi rozzuřeném býkovi během krásného sobotního odpoledne .
děti bojují , aby zvítězily v přetahování lanem .
cyklista na horském kole se naklání do zatáčky na hliněné stezce .
dva lidé a kráva uvázaná u domu .
mladý chlapec se učí jízdě na kole se svým tátou .
chlapec v červeném tričku a černých šortkách zametá příjezdovou cestu .
africká rodina stojí před provizorními domy .
muž hrající na nástroj vedle stromu .
dvě ženy se přes stůl drží za ruce a usmívají se na kameru .
funící hnědý pes jdoucí po trávě .
baseballová hráčka v černém triku právě vyoutovala hráčku v bílém triku .
žena drží obrovský šek pro kids food basket .
dva psi , z čeho jeden s tenisovým míčkem v puse , běží skrze vysokou trávu .
dva dospělí a dvě děti sedí na lavičce v parku .
žena na travnatém poli fouká na pampelišku .
muž prodává brambory skupině lidí .
lidé na ulici se shromažďují , aby si poslechli akordeon .
muž sedí na lavičce a poslouchá svůj ipod
starý muž v metru má na sobě teplé oblečení a čte si noviny .
starší muž v brýlích připravuje maso .
muž předvádějící trik na kole stojí na pedálech zatímco to kolo stojí na zadním kole .
muž je na pláži a staví písečné sochy .
několik lidí v parku jí u piknikového stolu
dvě ženy jsou přivázané ke stromu během jakési stavební práce .
kovboj , který se při rodeu snaží překonat 8 vteřin .
pes skáče přes ohnivou překážku .
žena s nadváhou s dlouhými černými vlasy a v růžovém tričku s cedulkou se jménem si nanáší rtěnku .
muž opravuje kolo malé holčičce .
dvě dívky v nadýchaných sukních tančí před nějakými hudebníky na ulici .
světlý pes si nese klacek podél vody .
dívka ve svetru blokuje sluneční paprsky .
probíhá rockový koncert .
tři ženy v jasných barvách s ozdobnými pokrývkami na hlavách drží kartičky s milostnými zprávami .
hnědý pes hrabe v hlíně .
malý chlapec v bílém pruhovaném triku a čelence drží tenisovou raketu .
dva psi běžící od fotoaparátu směrem do lesa .
dívka si hraje v kašně zcela oblečená .
tři mladí zápasníci sumo stojí a poslouchají uvaděče
dva turisté zkoumají kládu u lesní cesty .
tři hráči soupeřícího týmu sundávají protihráče k zemi .
dva chlapci přecházejí silnici zatímco si kopou do červeného fotbalového míče .
muž má jiného muže položeného na zádech .
bílý pes na horském svahu se za něčím mimo záběr otáčí , obloha v pozadí .
chlapec na skateboardu skáče na rampě
dlouhovlasý muzikant hraje na piano .
tři sportovci drží kytice na stupni vítězů .
dva holohlaví transvestité v červených šatech
malý chlapeček věší na věšák .
malá dívka v růžovém se drží tyče .
muž v zeleném skáče se svou motorkou přes několik motorek .
žena hrající si s dvěma mladými chlapci v parku
čtyři lidé hrají na pláži fotbal .
dvě náctileté dívky se objímají , jedna má na sobě helmu a za nimi jsou na pozadí cyklisté .
dva středně velcí psi běží sněhem .
žena stojí na zelené ploše , drží bílého psa a ukazuje na hnědého psa .
stůl plný obrázků v rámečcích na venkovním trhu .
dva lidi sedí u venkovního stolu naproti zdi a dělají obličeje .
dva chlápci s piercingy v bradavkách se usmívají .
dítě leží na béžovém koberečku a směje se .
muž a žena jsou do sebe zavěšeni , sedí a jsou vyšňoření .
dvě ženy zápasí v bahně v dětském bazénku .
chlápek v bílém triku kráčí s nápojem v ruce .
silueta dvou lidí u jezera odrážející barevnou oblohu .
několik lidí ve formálním oblečení sedí u stolu .
dvě dívky ( jedna oblečená v modrém , a ta druhá v růžovém ) proti sobě závodí na kolečkových bruslích .
čtyři lidé sedí na hromadě kamenů .
skupina lidí dělá triky na motorkách .
cyklista v závodním obleku jede přes zalesněnou plochu .
muž v zeleném tričku kráčí po pláži a nese si tenisky .
několik mužů stojí okolo starodávného závodního auta
dva muži pracují pod kapotou bílého závodního auta .
děti skáčou z hrany bazénu do vody .
muž padá z hrany zídky .
žena v pruhovaném oblečení na kole .
dívka oblečená v černém pózuje na kameru .
muž v šortkách stojící u vody .
čtyři černoši sedí na schodech kostela .
jeřáb operuje uprostřed hromady sutin .
gymnastka v červenobílém je v půlce otočky na bradlech .
starší žena v zeleném svetru vybírá zeleninu .
dva muži vyrábí produkty v dílně s nářadím .
učitelka v bílém a holčička ve žlutém si hrají se stavebními kostkami .
mladé dítě spící ve své posteli s otevřenou knihou na hrudi .
žena jí na trávě za krásného dne .
muž kráčí po dlážděné cestě vedoucí podél budov namalovaných na světlehnědo s červenými okapy .
žena s kloboukem dělá chléb .
osamocená žena používá velký primitivní hmoždíř a palici , aby rozdrtila rostlinný materiál , zatímco stojí v poli strnisek .
karatista vystupuje před dvěma rozhodčími .
muž ve formálním oblečení hraje na piano na chodníku ve městě .
postarší muž sedící na židli jí svačinu .
žena v bílé košili pracuje za barem v kavárně .
muž v pracovním oděvu stojí na zadní části nákladního vozu .
dvě děti se přes malý plot dívají na koně .
okno pomalované nějakým vzorem .
žena v zářivém růžovém kabátě dělá grimasu na ženu ve fialovém kabátě , zatímco stojí před obchodem s názvem vitamin shoppe .
kovboj si obmotová paži obinadlem .
muž ve žluté košili a muž v tmavém modrém tričku si povídají .
tři asijské děti sedí na gauči a za nimi visí tapiserie .
dívka v červeném triku skáče , aby se trefila do tenisového míčku .
muž pózující na kameru u zeleného jeřábu .
usmívající se muž si připíjí lahví v restauraci s další osobou .
muž nakládá pečené preclíky do nákladního vozu .
muž v černé bundě hrající na veřejnosti na kytaru .
taneční skupina účinkuje na průvodu v číně .
muž stojí na skalnatému útesu a shlíží na vodní hladinu .
policejní strážník se kouká na ženu , jak vystupuje z autobusu .
dva policisté ve střední letech v noci dohlížejí na parkoviště .
dva muži v modrých košilích pozorují fotbalový zápas .
skupina mužů v modrých uniformách stojí pohromadě .
mladá žena na pláži praktikuje jógu .
velký dav lidí stojí rozprostřen v parku a pár lidí hraje na nástroje .
muž s kloboukem z balónků vyrábí zvířata z balónků .
muž griluje maso na venkovním grilu .
dva muži prodávají ovoce na ovocném trhu .
hnědovlasá žena v bílých bikinách nalévá nápoj do mužova kelímku .
chlapec ve slunečních brýlích běží za trhem .
ruce v rukavicích drží něco , co se zdá býti nadrozměrně velkým hřebíkem na kmeni .
muž v kostkované košili předvádí pár černých rukavic .
dva muži na plastových židlích sedí u vchodu .
mladá dívka v červených šatech má černý kovbojský klobouk .
muž v červenobílém fotbalovém dresu stojí za autovou čarou se žluto-modrým fotbalovým balonem .
lidé skáčou na provaze přes horskou puklinu .
lidé se dívají na probíhající účastníky maratonu .
lidé u laptopů sedící před velkým oknem .
disk žokej je zaneprázdněný při práci a svítí na něj světla .
muž v rukavicích nese kukuřici přes pole .
fotografie zrcadlového odrazu kavárny .
muslimská žena drží balónky na islámské události
žena sedí v prostoru ohraničeném klecí s kočkou a dvěma králíky .
žena sedí u cihlové zdi uvnitř budovy .
tři mladé ženy jsou k sobě otočené čelem a sedí na červených nóbl křeslech .
žena v modré košili prochází vesnicí .
šest dětí sedí na schodech se zápisničky a pastelkami .
tmavý pes , který si na břehu hraje s klackem .
dva psi hravě okusují třetího psa , který vyplazuje jazyk .
dítě je na motorce a směje se .
6 lidí se shromáždilo u velké večeře .
santa klaus fotografován na prázdninové mediální události .
organizace válečné rodiny pochoduje new yorkem za deštivého dne .
žena v modré helmě a červených kalhotách jede na motorce .
několik mužů v oblecích na bojové umění předvádí společně nějaké pohyby .
mladá žena a muž oblečeni ve válečných kostýmech mávají holemi a v pozadí skupina lidí .
muž v uniformě kráčí po silnici se dvěma auty a stromem .
mladá žena leze na skálu
starší muž ve světle modré bundě opravuje auto na kraji silnice .
lidé se dívají na několik barevných papírků rozmístěných po stole .
muž , který zpívá do mikrofonu a hraje na kytaru .
dva muži sedící v restauraci .
dvě ženy v trenkách běží po pláži podél vody .
stavební dělníci diskutují podél kolejí .
pohled na pěší zónu zachycující muže v černé zástěře a bílé kšiltovce , který stojí uprostřed záběru .
skupina lidí si hraje na objektu .
malá dívka v modrém outfitu leze na ulici na kovové zábradlí .
skupina mužů sedí a povídají si za nějakým zeleným ovocem .
chlápek ve žlutém outfitu stojí ve stanu u mikrofonu .
hnědý pes s fialovým létajícím talířem v hubě .
vypadá to jako muž trénující bojová umění poblíž nějaké bahnité vody .
žena s nápojem a žena s mobilním telefonem .
dítě v červené bundě mává rukou ve vzduchu , zatímco leží ve sněhu vedle červených plastových saní .
žena sedí vedle své kabelky a kouká se na psy v parku .
tři muži stojí na pódiu , jeden má na sobě klauní makeup a drží kytaru .
žena zpracovává tekutinu z rostlin ve kmenové vesnici
žena v červených šatech tančí s mužem v obleku .
dva malí psi pronásledují většího psa s tenisákem .
muž s přerostlou bradkou a v baseballové čepici sedí v parku na lavičce .
africký kmen stojí v zahradě a na pozadí les.
mladá dívka se snaží kartáčovat kozu .
asiaté sedí v restauraci se žlutými židlemi .
malá holčička jí sušenku usazena v jídelní židličce a má na sobě bryndák .
šedovlasý muž s černými rukavicemi seká trávník .
žena , která si čte knihu , zatímco sedí v řadě červených židlí .
dítě tleská zatímco je na ženiných ramenech .
rodina , která jde po chodníku skrze sníh , zatímco muž sedí na straně s papírovým kelímkem .
kočka sedí na vrchu cedule obchodu .
muž v růžovém tričku a černém kabátě s nasazenými sluchátky .
mladý muž se chystá hodit míčem na americký fotbal .
chlapec a dívka jdou dolů po točitém chodníku .
žena s růžovými vlasy dřepí na chodníku a drží růžové psy .
muž v obleku držící nápoj v kelímku jde po chodníku vedle autobusu městské hromadné dopravy .
muž skáče a za sebou má skalnatý útvar .
osoba v červené bundě a černých kalhotách drží duhovou stuhu .
žena pokládající ruku na osobu , která sedí na invalidním vozíku .
muž v bílé zástěře vaří něco na pánvi s vajíčky pro ženu ve světle hnědém kabátě .
žena s mobilním telefonem a sluchátky čeká na přechodu .
skupina mužů kráčí dolů ulicí .
cesta vedle zajímavého místa s mnoha sloupky .
skupina lidí v černém stojí na molu poblíž dlouhé konstrukce .
muž nesoucí několik beden piva .
muž ve středních letech sedí a hraje na akordeon .
dívka se zelenou páskou na ruce , gumičkami a náušnicích ve vlasech stojí venku .
malá dívka v růžovém tričku je na pláži a běží vstříc oceánu .
skateboardista v černém triku a džínách skejtuje po městě .
muž v bundě si fotografuje velkou budovu .
lidé za postranní čárou během fotbalového zápasu .
na této fotografii je čtyřčlenná rodina běžící přes rušnou ulici ve městě .
skupina lidí kráčí na slunci .
na ulici s dopravními světly je několik lidí , včetně muže v hnědém kabátu a slunečních brýlí , který má ruku na obličeji .
nějaké květiny rostou u okna .
tento hráč v modré helmě byl na pálce , právě dokončil odpal během baseballového zápasu .
žena ve zlatém kabátě spěchá na metro .
lidé sedí na lavičkách pod řadou stromů před budovou .
muž v obleku sedí na autobusové zastávce .
afroameričan obklopený prázdnými vzhůru otočenými bílými kýbly a tmavě zabarvenými bednami se vyjadřuje za pomocí zprávy , která je napsaná rukou na kartonu .
mladá brunetka něco jí a pije .
muž v obleku a klobouku hraje na ulici na kytaru .
žena v červené vestě pracuje na počítači .
lidé stojí okolo kadidla a vanou si kouř do obličeje .
muž se dívá do zrcadla , aby si uvázal kravatu .
několik lidí hraje hudbu , zatímco šťastný dav sedí a poslouchá .
dva mladí muži jedoucí na velmi malém koňském povozu plném brambor .
žena v šatech jdoucí dolu ulicí podél staveniště .
zaměstnankyně obchodu žádá zákazníka , který si kupuje alkohol , aby jí ukázal občanský průkaz .
muž se slunečními brýlemi řídí stavební vůz a sype štěrk na zem .
dítě si hraje s hračkami a kouká se na černobílou kočku .
náctiletá dívka si nese lesem kytaru .
muž s batohem kráčí po ulici .
dva muži konverzují před obchodem se suvenýry v římě .
žena v černém něco drží ve své puse .
skupina lidí sedí venku okolo malého krátkého stolečku .
muž skáče se svým kolem nad rampu .
žena má na sobě černé tílko a náhrdelník s křížem a zírá do dáli s brzy zapadajícím sluncem .
tři malé dívky spolu kráčí po chodníku .
žena s dlouhými vlasy je na promoci .
muž jede na po silnici na skateboardu , zatímco jiný muž ho pozoruje z chodníku .
muž v černé kožené bundě stojí před nápisem .
muž a žena spolu venku zpívají píseň .
malá dívka s blonďatými kudrnatými vlasy v bílém svršku leží na trávě a drží květinový stonek .
mladý ženský fotbalový tým v zelených dresech provádí protahovací cvičení .
žena sehrává dramatickou scénu na veřejnosti za žlutou policejní páskou .
muž se krčí při domácích pracích , zatímco se holubi procházejí na pozadí .
skupina mužů stojí na poli s černými míčky .
rušný den pro občany na místním městském soudě .
muž s cigaretou v puse si připravuje talíř s jídlem .
dvě skupiny plavců se brodí .
lidé sedí na lavičce na městském náměstí s různými předměty zahrnujícími také poblíž stojící lampu a figurínu .
dělníci stojí kolem díry a drží kbelík .
muž bez trička v černých kraťasech stojí na skalnatém pobřeží vedle velké masy vody .
strážný je během služby na obhlídce .
lidé hrající kulečník - jeden muž má na sobě modrou košili a ty ostatní jsou ženy , ale jejich hlavy nejsou v záběru .
lidé stojí před sochou obklopenou vodou .
žena se dívá na mluvícího muže s překříženýma rukama .
muž ve středním věku s bílými šortkami a v žabkách se rozhlíží po ulici .
dva muži oblečení v tmavě oranžových hábitech stojí poblíž zrcadlící se sochy .
dva lidé si užívají na své lodi .
muž a žena stojí na ulici ve městě .
hasiči vycházejí ze stanice metra .
čtyři muži z nichž tři mají na sobě modlitební pokrývky hlavy sedí na modroolivovězelené vzorované podložce .
toto je velká skupina lidí sedících venku na lavičkách .
muž v červeném tričku jde kolem tyrkysovobíle kostkovaného stravovacího zařízení , které se nazývá &quot; 32 de neude . &quot;
lékaři provádějí jakýsi druh operace .
starší muž s cigaretou v ústech a baseballovou čepicí kontroluje svůj fotoaparát .
malý orchestr hraje s před sebou otevřeným houslovým futrálem
muž v červeném obleku tančí se ženou .
dva lidé se dívají na noční osvětlené město .
dva motokrosaři mají na sobě plnou ochrannou výstroj , jeden z nich ve vzduchu po výskoku a druhý dívající se na svou motorku .
několik mužů oblečených do oranžova se shromažďuje na venkovní společenskou akci .
dvě mladé dívky kráčí po chodníku před cihlovou budovou se standartami .
dva jedinci lezoucí po strmé hoře .
dítě leží na zemi vedle kočárku .
pes škemrá u muže a ženy .
mnoho lidí na trhu se dívá na rozličné věci .
dva mladí muži hrají na pódiu na elektrické kytary .
potetovaný muž , který lije pivo z láhve do úst mladého muže .
dva lidé stojí u nafukovacích hraček a košů .
čtyři lidé jedou na kolech po cyklistické stezce poblíž rušné silnice .
žena v růžové košili má na sobě brýle .
žena v červeném triku zvedá paži k davu pod ní .
chlapec v bílých šortkách skáče do jezera nebo do řeky .
malá dívka kouká dalekohledem na pláž .
několik dělníků v oranžových bezpečnostních vestách kope dírů do země .
osoba v kapuci stojí před chátrající budovou .
dělníci stávkují proti pm construction services .
muž jede na běžícím koni a za ním několik mužů dělá to samé .
afroameričan kráčí po ulici .
dvě jeptišky pózují na kameru .
žena se zářivými sluchátky si píše do zápisníku .
žena v zeleném tričku s potiskem mluví do mobilního telefonu .
malé africké dítě nese na zádech mladší dítě .
skupina lidí sedí na židlích .
člověk s šátkem na hlavě stojí na ulici před jeho věcmi .
orientální osoba v červeném triku a černých kalhotách dřepí u kabelky na chodníku .
černý a hnědý pes s balonem .
muž v černé bundě držící model letadélka
muž na poli a ve výhledu letadlo .
muž v obleku a kravatě a žena se zavazadlem se přidávají k ostatním čekajícím v londýnském metru .
dítě jde po chodníku s pár americkými vlajkami .
černý pes běží po zelené trávě a v hubě má hračku .
orientální cestovatel čeká , až na něj přijde řada ve směnárně .
pes se otáčí na trávě , aby chytil letící míček .
skupina studentů sedí a poslouchá přednášející .
lidé , kteří jedou v noci po ulici na skútrech .
velké šedivé molo u moře a na něm chlápek na kole .
muž v oranžovém triku , blonďatý chlapec a další lidé jedou na vláčku s nápisem pullman .
mladý muž a žena u velké kovové sochy
loď s červenobílomodrými plachtami kotví u mola .
muž v černé čepici fotografuje na rušné ulici .
muž stojí na rušné ulici a zírá s nakloněnou hlavou .
žena v černém má na ramenou malou holčičku ve žlutých šatech .
skupina lidí na ulici ladící nástroje .
spadlému motorkáři na hlíně pomáhá další motorkář .
tři lidé kráčí po horské stezce a jedna z žen se dívá na kameru .
několik asijských mužů v černých oděvech na jakési stanici .
žena v červené sukni kráčí po ulici a na pozadí jsou graffiti .
sportovní gymnastka v modro-růžovém dresu předvádí sestavu se stuhou .
lidé se chladí ve fontáně , žena v bílých šatech sedí na jejím kraji a pozoruje dění .
muž sedí na lavičce pod velkým stromem .
tři muži v červenobílých proužkovaných tričkách , bílých kalhotech a černých kloboucích drží vlajky .
lidé obdivující výtvarné dílo .
rušné asijské obchodní centrum s papírovými lampiony a nákupčími .
tito lidé lezou po schodech na horu vedoucí k hoře
malé dítě v modrém outfitu se dívá na stromy v dálce .
lidé se dívají na dětské hračky v obchodě .
muž v klobouku hraje na ulici na bubny .
chlapec stojí se třemi dívkami .
muž , který se směje a má na sobě batoh , drží pěsti před chlapcem v brýlích .
čtyři muži jsou venku a dívají se dolů ze zeleného mostu .
žena polehává na osušce před lidmi , kteří si užívají v modré vodě .
dospělý australský ovčák běží za štěnětem australského ovčáka .
nakupující a milovníci jídla jsou zachyceni v ruchu města .
afroameričan protestuje proti nezákonnému sexu .
policajt na motorce čeká na světlech , až padne zelená .
skupina mužů sedí okolo stolu .
skupina obchodníků z vyšší třídy včetně starších mužů pijí v parku .
žena se baví s kamarádkou , zatímco venčí psa za slunečného dne .
mladý muž v šedočerném triku a bílé čelence
dva lidé jedou na motorce vedle mnoha dalších jezdců .
dvě ženy ve vojenských uniformách stojí s ostatními vojáky ve formaci .
tři dívky se usmívají na fotografii .
žena v brýlích s černými obroučkami a ve žluté mikině vypadá zmateně během toho , co sedí na světlehnědé lavičce .
zrzavý mladý muž pije vodu z pítka ve tvaru ženy .
dva muži a žena kráčejí po ulici .
muž ve středních letech se zrzavými vlasy a brýlemi drží kojence .
malý chlapec v červené kšiltovce jede na koni .
dva chlapci si hrají na chodníku .
malá holčička v černých plavkách drží na pláži lopatičku .
starý muž v klobouku a saku , který sedí na pohovce a spí .
dva chlapci se dívají nahoru na oblohu a mávají pažemi a mají na sobě oblečení , ve kterém jim bude teplo .
mladý pár sedí na chodníku a odpočívají spolu .
dřepící mladík má na sobě košili a kravatu a ukazuje gesto míru .
tři lidé sedí venku u stolu v baru gelati tabacchi .
chlapec v černém triku a s červenými náramky visí vzhůru nohama , zatímco se na něj ostatní lidé dívají .
muž před pestrobarevnou malbou na zdi .
mladý muž jde s jiným mladým mužem , který se dívá na tři dívky , které kolem nich zrovna prošly
muž zastřihává palmu vevnitř kavárny v patio stylu .
pět lidí jde nahoru po schodech a vede je žena v růžovém triku a hnědé sukni .
skupina lidí na venkovním ovocném trhu
dva chlapci jedí venku na zahrádce oběd z mcdonaldu a jsou obklopeni mnoha lidmi .
žena , která má na sobě džínovou bundu , jde po chodníku
muž řídí vozidlo na čtyřech kolech s čtyřmi pasažéry vpředu a mužem sedícím bokem vzadu .
muž v tyrkysovém triku čte noviny .
chlapec v kočárku má na sobě zelené triko a drží knihu .
dvě děti sedí vedle sebe a jedí dobrotu .
lidé , kteří jedou na kole po ulici a všichni mají helmy .
dav lidí a všichni jedou na kolech .
muž sedící na desce s koly je tažen norou .
muž na kole šlape skrze klenutý průchod .
barevně oblečený mladý muž s viditelnými poškozeními na tváři sedí a kouří cigaretu .
dva muži v oblecích pod deštníkem a před graffiti .
starý hubený muž má na sobě špinavé bílé triko a jede na kole po silnici
muž na koňském hřbetu se snaží chytit do lasa mladého býčka .
kovboj jedoucí na koni se pokouší do lasa chytit býčka .
dva cyklisté v helmách jedou kolem prázdných polí .
muž se ohýbá a vytahuje něco z tašky .
muž na elektrickém vozíku se jede podívat na areál parku .
osoba s tetováními se dívá na fotografii na digitálním fotoaparátu nebo mobilu .
muž v černém triku a džínách stojí na chodníku a kouká se na kameru .
chlapec a dívka spolu stojí na chodníku a dívají se na nějaký předmět .
několik lidí v modrých zákrscích a jedna osoba v sukni a černé blůze .
žena a pes sedí na bílé lavičce poblíž pláže .
dvě ženy kráčí po hlíně před velkou budovou .
skupina mužů a dítě v bílém triku stojí na silnici .
žena oblečená celá v černém si nese po chodníku černou kabelku
skupina mužů sedících u stolu se baví .
malba na zdi na straně budovy .
asiat má na sobě rukavice a pracuje u stánku s jídlem .
žena sedící u stolu při práci na svém přenosném počítači .
osoba dívající se na počítač na stole s mobilem a krabicí .
muž sedící na židli kouká na procházející lidi .
dva lidé v kloboucích stojí na poli a pečují o sklizeň .
skok do výšky v barceloně .
muž v jezdeckých botách a kovbojském klobouku sedí na koni , který skáče a diváci sedí na tribuně .
dvě malé dívky sedí na silnici a pojídají kukuřici .
tři děti ve fotbalových uniformách dvou různých týmů hrají fotbal na fotbalovém hřišti , zatímco další hráč a dospělý stojí v pozadí .
malé dítě se špinavou pusou je drženo starou ženou .
muž s brýlemi se kouká na kameru zatímco jiný muž v modrém triku se na něco soustředěně kouká .
dva lidé sedí pod stromem a sbírají zelenou zeleninu .
mladý chlapec má na sobě modrou čepici , dívá se do dalekohledu , zatímco jiný chlapec ho pozoruje .
3 muži vaří v malé kuchyni .
malá dívka má na sobě šedou kombinézu a lyžuje na zasněžené hoře .
skupina vesnických žen shromážděna u tance
muž a žena třídí prádlo v latexových rukavicích .
mladá dívka sedící na dřevěné židli .
dva pracovníci svářejí tyče plotu na rušné předměstské ulici .
dlouhovlasý mladý muž skateboarduje na zábradlí během zamračeného dne .
dva muži odklízejí lopatami sníh z cesty na venkovním tržišti .
muž v bílé košili hraje na bílou kytaru .
mladá dívka ukazuje kamarádkám fotoaparát na jedno použití .
malý chlapec , který skáče z mola do jezera .
žena se zelenou rouškou u zubaře vypadá velmi nešťastně .
muž v oranžové bundě a modré čepici leze na zasněžené hoře .
malá dívka s blonďatými vlasy si hraje a cáká v kaluži s bahnem .
dítě jede na kole uličkou s graffiti .
gymnastka je hodnocena na soutěži .
lidé kráčí ulicí , kde je pouliční prodavač .
muž oblečený v tradičním oděvu stojí vedle své muly , která také vypadá oblečeně .
dvě děti si hrají na kole .
dva muži soupeřících týmů hrají na hřišti fotbal .
muž skáče a pózuje pro fotografa ležícího na zemi .
dívka pije vodu z pítka .
jeskyňář nalézá vodu během své túry .
muž v laboratorním kabátu se dívá do mikroskopu .
blonďatá dívka spí na hnědém gauči .
muž zametá chodník před zděnou budovou uprostřed dne .
tři muži vaří v kuchyni .
muž na lešení před domem se směje a pózuje pro fotografa .
dvě dívky v šortkách se drží za ruce v bazénu .
čtyři asijské děti sedí na lavičce a mávájí a usmívají se na kameru .
děti jedou na kolech v nějakém chudém státě .
malý chlapec v šéfkuchařské čepici a zástěře řeže klobásy v kuchyni .
toto je klaun na základní škole .
kapitán lodi se usmívá a drží kormidlo své dřevěné lodi .
žlutý buldozer přesouvá hlínu .
žena v červené košili jede na úplně bílém koni , který cválá podél stromů .
žena sedící na velmi velkém kameni , usmívající se na kameru , se stromy v pozadí .
tři muži mající na sobě zářivé kostýmy , paruky a bláznivé brýle vyrážejí do ulic .
dívka si hraje v malém bazénku .
dvě děti , chlapec ve žlutém triu a dívka v modrobílo pruhovaném , se houpou .
muž hází rybářskou síť do zálivu .
muž mající na sobě šedé tričko , modré džíny , neonovou zelenou bezpečnostní vestu stojí na železniční koleji a na pozadí je bílé nákladní auto a bílá budova .
dva dělníci pokládají kus kovu přes trámy .
na pódiu je kapela , která je oblečená do modrého .
rocker bez trika zpívá do mikrofonu a hraje přitom na bicí .
vidím muže , který vyndavá věci z nákupního košíku , aby jej mohli zkontrolovat .
muž s holí je na procházce .
žena v bílém triku cvičí na eliptickém trenažéru .
dívka s maskou se nosí na mužových ramenech a jdou po zaplněném chodníku .
dvě dívky , jedna starší v černém a druhá mladší v bílém předvádějí ten samý baletní pohyb před dekorací z balonků .
několik žen předvádí tanec před budovou .
plešatý muž kráčí po chodníku dolů a při tom hovoří na mobilu .
žena si hraje s prstovými maňásky zatímco dítě v kostýmu prochází okolo .
skupina lidí pozoruje mladé muže , kteří hrají na bubny ze kbelíků sloužících jako hudební nástroje .
dívka s normálními a improvizovanými chrániči na kolečkových bruslích .
malé bílé auto je na vlakových kolejích a možná bylo , možná nebylo zasaženo vlakem za ním .
dva rockeři zpívají a hrají na tmavém pódiu .
dívka v kšiltovce , bílém tričku a modrých šortkách stojí v potoce s kameny na dně a kolem jsou hory a lesy .
dva muži hrají na kytaru před velkým publikem .
skupina lidí tancuje se svými drahými polovičkami před tímto obrovským domem .
žena a pes prodávají výrobky na schodech staré budovy .
žena a dva muži , kteří jsou profesionálně oblečeni , se baví .
skupina mužů v červenočerných bundách čeká na motorkách .
muž oblečený v bílém dresu s číslem 3 hraje fotbal .
muž prodává malé občerstvení na sportovní události .
dva muži ze zeleného týmu se snaží obrat členy černého týmu o balon během rugbyového zápasu .
děti soutěží o držení fotbalového balonu .
osoba v modrém je momentálně jedinou osobou házející svou kouli na bowlingové dráze .
několik fotbalových hráčů na hřišti v akci .
mladý muž sedí na skateboardu , drží mobil a pózuje na eskalátoru .
dáma oblečené v modrém běží maraton .
tato kapela se připravuje na vystoupení v kostele před diváky .
hráč číslo 8 týmu iowa state odstrkuje rukama hráče texasu am , který se ho snaží sundat dolů .
dva hráči curlingu zametají led před kamenem a malý dav je pozoruje .
muži hrají fotbal na bahnitém hřišti .
basketbalový hráč v bílém je v podřepu zatímco hráč v červeném jde proti němu .
lidé kráčí pod obloukem ve staře vypadajícím městě .
dvě závodní auta , jedno červené a druhé modré , jedou vedle sebe po závodní dráze , zatímco je pozoruje několik diváků .
hráč amerického fotbalu v bílém dresu drží balon .
velmi mladý chlapec se kouká dopředu , zatímco se zakusuje do malého předmětu .
žena a dítě jdou po ulici .
hokejový zápas se hraje se spoustou lidí , kteří jej sledují .
tři ženy skáčou na balonech po trávě .
afroamerický chlapec v modrých šortkách , černočerveném tričku a bílých teniskách hraje tenis .
muž a žena v bílých trikách se navzájem objímají .
muž , který promlouvá k rodině , zatímco drží jakési snímací zařízení , se usmívá a snaží se být milý .
malý chlapeček v zeleném tričku leží na břiše na bílé posteli .
freestylový cyklista se zastavuje , aby si odpočinul a na pozadí je západ slunce .
žena lyžuje v zasněžené oblasti a má na sobě teplé oblečení .
čtyři dívky a jedna dáma se učí ručním pracím .
muž v černobílopruhovaném se snaží zastavit koně .
muž skenuje obrázek , který mu dává žena v modré košili .
zrzavá žena je po krk ponořená v kalné modré vodě .
dva malí hoši pózují se štěňátkem na rodinné fotografii .
čtyři děti trénují karate zatímco se dva dospělí dívají .
muž polehává na červené pohovce v showroomu s nábytkem .
skupina lidí povídajících si u stolů .
dva žokeji , jeden v červenomodro kostkovaném a ten druhý v oranžovohnědém proti sobě závodí a pozadí je rozmazané .
červené auto je napřed dvou aut v pozadí .
velký býk útočí na muže svými rohy v rodeu , je kousek od něj a rodeo klaun běží na pomoc .
muž bez trička kráčí ke žlutému kajaku .
chlapec na střelnici míří a střílí .
dva týmy chlapců hrají fotbal v písku .
dítě v modrém a dítě v bílém stojí na krátké betonové zídce u potoka .
žena kreslí květinový motiv na hliněnou vázu .
lidé se procházejí po rušné třídě v cizí zemi .
pravoruký nadhazovač z týmu saints nadhazuje .
dva muži , jeden v černobílém a druhý v červeném , hrají plážový volejbal .
muž stojící na lodi drží jakousi síťovinu .
surfař , který spadl ze surfařského prkna do oceánu při snaze sjet vlnu .
technik připravující vzorek v laboratoři .
fotbalisté skáčou do vzduchu , aby odrazili balon svými hlavami .
dva chlapci hrají proti sobě fotbal .
starší osoba přechází silnici s deštníkem v ruce .
skupina běžců běží směrem k identickým mrakodrapům .
skateboardista jede nahoru po betonové zídce a téměř padá u předvádění triku .
lidé hrají utkání v bazénu .
chlápek davá pusu jinému chlápkovi
muž se podepisuje malému chlapci do knihy .
mladý muž v modrém triku sjíždí zábradlí na skateboardu v městské části .
asiat sedí na kolejích s bednami buráků .
britský muž oblečený do vojenské uniformy mává svým kloboukem a za ním stojí lidé a koukají se na vodní kanál .
dvě auta jedou po závodní dráze .
muž v černobílém dresu drží žluté lyžařské hole a připravuje se k odjezdu .
dva lidé leží a líbají se na trávě .
velmi malé dítě v denimové kšiltovce jí zelené jablko .
hráči amerického fotbalu běží za balonem .
muž v černé bundě , kostkovaném klobouku a pruhovaných kalhotách hraje na pódiu na elektrickou kytaru a na pozadí je zpěvák a další kytarista .
muž skáče přes zátarasu pryč od býka .
žena v modrém triku a bílých šortkách hraje tenis .
muž hraje na pohřeb na koncertu
muž nese na ramenou velký náklad kovových trámů přes sklad dřeva .
žena s kamerou hází svému hnědému psovi létající talíř , aby ho chytil .
je tam obrys muže a ženy , kteří pozorují táborák nebo jinak velký hořící dřevěný objekt .
dvě dívky si namáčejí ruce ve fontáně a kolem nich chodí lidé .
mokré , usmívající se dítě bez trička pózuje se zdviženýma rukama .
dva muži , jeden v bílém a druhý v modrém , zápasí .
žena v červených bikinách skáče , aby odpálila míč na plážovém volejbale .
zrzavé pruhované koťátko kouše blondýnu do nosu
žena má na sobě žlutou zástěru a odklápí poklici z velkého hrnce .
dvě děti přecházejí říčku po kamenném můstku .
dvě afroameričanky jedou na mopedu ulicí , která se zdá být ve velmi ucpané oblasti velkého města .
dva chlapci před automatem na limonádu .
cyklista v černém , jede na horském kole dolu po prachové stezce .
žena s tetováními si fotí na mobil obraz .
žena , téměř celá v černém oblečení a s bílou helmou , jede na kole , v pozadí jsou rozmazané stromy .
tým cyklistů zatáčí zatímco jim fandí poblíž stojící diváci a fotografují si je .
čtyři hráči amerického fotbalu napadají za deště hráče soupeřova týmu hrajícího v bílém .
běžec se rve o yardy zatímco ho dva hráči sundavají k zemi .
basketbalista v bílém dresu s číslem 55 brání hráče v černém dresu s číslem 10 .
muž venku hovoří do telefonu .
závodní baseballoví hráči se během all star utkání dívají na soupeře na pálce .
motokrosař jede v podzimním lese do nakloněné zatáčky .
3 basketbaloví hráči soupeří o balon , z nichž ten v červeném dresu se snaží vzít balon tomu v bílém dresu .
chlapec , který se popadá za nohu , když skáče do vzduchu .
dvě děti s pruhovanými svetry a černými kalhotami se perou poblíž prolézaček .
muž se slunečními brýlemi jede na koloběžce .
malý chlapec mající na sobě korunovační insignii drží pálku za hlavou a před ním je postavený baseballový míček .
šest mužů sedí v poli plodin a vedle nich bedýnky .
hnědý pes zvedá větvičku z kamenného povrchu .
toto je muž oblečený ve žlutém a drží opratě hnědého koně
muž v bílé košili a zástěře čtvrtí ptáka .
hispánská žena používá venkovní wok k vaření .
maratonší běžci závodí po ulici ve městě a okolo stojí lidé .
asijská žena má na sobě klobouk proti slunci a jede na kole .
několik dětí si venku hraje s hlínou u dvou stromů .
starší muž hraje video hry .
dívka na břehu pláže s horami v dáli .
